declare const router: import("@types/express-serve-static-core/index.js").Router;
export default router;
//# sourceMappingURL=users.d.ts.map