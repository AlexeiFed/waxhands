/**
 * @file: paymentService.ts
 * @description: Сервис для обработки платежей и обновления счетов
 * @dependencies: database connection, types
 * @created: 2025-01-26
 */
import pool from '../database/connection.js';
/**
 * Обновляет статус счета и связанные данные в базе данных
 */
export const updateInvoicePaymentStatus = async (paymentData) => {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        console.log(`🔄 Обновляем счет ${paymentData.invoiceId}: статус=paid, payment_id=${paymentData.paymentId}`);
        // Обновляем счет
        const updateResult = await client.query(`UPDATE invoices 
             SET status = $1, 
                 payment_id = $2, 
                 payment_method = $3, 
                 payment_date = $4, 
                 updated_at = CURRENT_TIMESTAMP 
             WHERE id = $5 
             RETURNING *`, ['paid', paymentData.paymentId, paymentData.paymentMethod, paymentData.paymentDate, paymentData.invoiceId]);
        if (updateResult.rows.length === 0) {
            console.error(`❌ Счет ${paymentData.invoiceId} не найден`);
            await client.query('ROLLBACK');
            return {
                success: false,
                message: `Счет ${paymentData.invoiceId} не найден`,
                error: 'Invoice not found'
            };
        }
        const invoice = updateResult.rows[0];
        console.log(`✅ Счет обновлен:`, {
            id: invoice.id,
            status: invoice.status,
            payment_id: invoice.payment_id,
            payment_method: invoice.payment_method,
            payment_date: invoice.payment_date
        });
        // Синхронизируем статус оплаты с участниками мастер-класса
        if (invoice.master_class_id && invoice.participant_id) {
            try {
                console.log(`🔄 Синхронизируем статус оплаты для участника ${invoice.participant_id}`);
                // Получаем текущий мастер-класс
                const masterClassResult = await client.query('SELECT participants, statistics FROM master_class_events WHERE id = $1', [invoice.master_class_id]);
                if (masterClassResult.rows.length > 0) {
                    const masterClass = masterClassResult.rows[0];
                    let participants = masterClass.participants || [];
                    // Обновляем статус оплаты для участника
                    participants = participants.map((p) => {
                        if (p.id === invoice.participant_id) {
                            return { ...p, isPaid: true, paymentDate: paymentData.paymentDate };
                        }
                        return p;
                    });
                    // Пересчитываем статистику
                    let totalPaidAmount = 0;
                    let totalUnpaidAmount = 0;
                    participants.forEach((p) => {
                        if (p.isPaid) {
                            totalPaidAmount += p.totalAmount || 0;
                        }
                        else {
                            totalUnpaidAmount += p.totalAmount || 0;
                        }
                    });
                    // Обновляем мастер-класс
                    await client.query(`UPDATE master_class_events 
                         SET participants = $1, 
                             statistics = jsonb_set(
                                 COALESCE(statistics, '{}'::jsonb), 
                                 '{totalPaidAmount}', 
                                 $2::jsonb
                             ),
                             statistics = jsonb_set(
                                 statistics, 
                                 '{totalUnpaidAmount}', 
                                 $3::jsonb
                             ),
                             updated_at = CURRENT_TIMESTAMP
                         WHERE id = $4`, [JSON.stringify(participants), totalPaidAmount, totalUnpaidAmount, invoice.master_class_id]);
                    console.log(`✅ Статус оплаты синхронизирован для мастер-класса ${invoice.master_class_id}`);
                }
            }
            catch (error) {
                console.error(`❌ Ошибка синхронизации статуса оплаты:`, error);
                // Не прерываем транзакцию, если синхронизация не удалась
            }
        }
        // Создаем запись о платеже
        await client.query(`INSERT INTO payment_history (
                invoice_id, payment_id, amount, currency, payment_method, 
                payment_date, sender, operation_id, label, created_at
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, CURRENT_TIMESTAMP)`, [
            paymentData.invoiceId,
            paymentData.paymentId,
            paymentData.amount,
            paymentData.currency,
            paymentData.paymentMethod,
            paymentData.paymentDate,
            paymentData.sender || null,
            paymentData.operationId,
            paymentData.label || null
        ]);
        await client.query('COMMIT');
        return {
            success: true,
            message: `Счет ${paymentData.invoiceId} успешно обновлен на статус 'paid'`,
            invoiceId: paymentData.invoiceId,
            paymentId: paymentData.paymentId
        };
    }
    catch (error) {
        console.error(`❌ Ошибка обновления счета ${paymentData.invoiceId}:`, error);
        await client.query('ROLLBACK');
        return {
            success: false,
            message: `Ошибка обновления счета ${paymentData.invoiceId}`,
            error: error instanceof Error ? error.message : 'Unknown error'
        };
    }
    finally {
        client.release();
    }
};
/**
 * Находит счет по метке платежа или отправителю
 */
export const findInvoiceByLabel = async (label) => {
    try {
        const result = await pool.query('SELECT id FROM invoices WHERE payment_label = $1 AND status = $2', [label, 'pending']);
        return result.rows.length > 0 ? result.rows[0].id : null;
    }
    catch (error) {
        console.error('❌ Ошибка поиска счета по метке:', error);
        return null;
    }
};
/**
 * Находит счет по отправителю
 */
export const findInvoiceBySender = async (sender) => {
    try {
        const result = await pool.query('SELECT id FROM invoices WHERE sender_phone = $1 AND status = $2', [sender, 'pending']);
        return result.rows.length > 0 ? result.rows[0].id : null;
    }
    catch (error) {
        console.error('❌ Ошибка поиска счета по отправителю:', error);
        return null;
    }
};
//# sourceMappingURL=paymentService.js.map