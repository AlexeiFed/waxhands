import { Router } from 'express';
import crypto from 'crypto';
import pool from '../database/connection.js';
import { updateInvoicePaymentStatus, findInvoiceByLabel } from '../services/paymentService.js';
import { sendPaymentSuccessNotification } from '../services/notificationService.js';
import { handlePaymentError } from '../services/retryService.js';
const router = Router();
// Функция для валидации подписи от ЮMoney
const validateYuMoneySignature = (req, body) => {
    try {
        // Получаем секретное слово из переменных окружения
        const notificationSecret = process.env.YUMONEY_NOTIFICATION_SECRET;
        if (!notificationSecret) {
            return true; // Пропускаем валидацию если секрет не настроен
        }
        // Формируем строку для проверки согласно документации ЮMoney
        const paramsString = [
            body.notification_type,
            body.operation_id,
            body.amount,
            body.currency,
            body.datetime,
            body.sender,
            body.codepro,
            notificationSecret,
            body.label || ''
        ].join('&');
        // Вычисляем SHA1 hash
        const calculatedHash = crypto.createHash('sha1').update(paramsString, 'utf8').digest('hex');
        // Сравниваем с полученным hash
        const isValid = calculatedHash === body.sha1_hash;
        return isValid;
    }
    catch (error) {
        console.error('❌ Ошибка валидации подписи:', error);
        return false;
    }
};
// Webhook для ЮMoney
router.post('/yumoney', async (req, res) => {
    try {
        console.log('📋 Headers:', JSON.stringify(req.headers, null, 2));
        console.log('📦 Body:', JSON.stringify(req.body, null, 2));
        // Проверяем что это form-urlencoded данные (стандарт ЮMoney)
        if (req.headers['content-type']?.includes('application/x-www-form-urlencoded')) {
            const webhookData = req.body;
            // Определяем источник данных - НОВАЯ ЛОГИКА
            // ЮMoney всегда отправляет notification_type и sha1_hash
            const isFromYuMoney = webhookData.notification_type && webhookData.sha1_hash;
            // Проверяем тестовый режим
            const isTestMode = process.env.NODE_ENV === 'development' || process.env.ENABLE_TEST_WEBHOOK === 'true';
            const isTestRequest = req.headers['x-test-webhook'] === 'true' || webhookData.test_notification;
            // Если это уведомление от ЮMoney - обрабатываем как ЮMoney
            if (isFromYuMoney) {
                // Проверяем подпись ЮMoney (пропускаем в тестовом режиме)
                if (!isTestRequest && !validateYuMoneySignature(req, webhookData)) {
                    console.error('❌ Неверная подпись от ЮMoney');
                    res.status(401).json({
                        success: false,
                        error: 'Unauthorized - Invalid signature'
                    });
                    return;
                }
                if (isTestRequest) {
                }
                else {
                }
                // Обрабатываем в зависимости от типа уведомления
                if (webhookData.notification_type === 'p2p-incoming' || webhookData.notification_type === 'card-incoming') {
                    // Ищем счет по метке
                    let invoiceId = null;
                    if (webhookData.label) {
                        invoiceId = await findInvoiceByLabel(webhookData.label);
                    }
                    if (invoiceId) {
                        try {
                            // Обновляем статус счета
                            const paymentData = {
                                invoiceId,
                                paymentId: webhookData.operation_id,
                                amount: webhookData.amount,
                                currency: webhookData.currency,
                                paymentMethod: webhookData.notification_type === 'p2p-incoming' ? 'P2P transfer' : 'Card payment',
                                paymentDate: webhookData.datetime,
                                sender: webhookData.sender,
                                operationId: webhookData.operation_id,
                                label: webhookData.label
                            };
                            const result = await updateInvoicePaymentStatus(paymentData);
                            if (result.success) {
                                // Отправляем уведомления
                                try {
                                    const invoiceResult = await pool.query('SELECT participant_id FROM invoices WHERE id = $1', [invoiceId]);
                                    if (invoiceResult.rows.length > 0) {
                                        const userId = invoiceResult.rows[0].participant_id;
                                        await sendPaymentSuccessNotification(userId, invoiceId, webhookData.amount, paymentData.paymentMethod);
                                    }
                                }
                                catch (notifyError) {
                                    console.error('❌ Ошибка отправки уведомления:', notifyError);
                                }
                            }
                            else {
                                console.error(`❌ Ошибка обновления счета ${invoiceId}:`, result.error);
                                await handlePaymentError(webhookData.operation_id, result.error || 'Failed to update invoice', undefined, invoiceId);
                            }
                        }
                        catch (dbError) {
                            console.error(`❌ Ошибка обработки платежа:`, dbError);
                            await handlePaymentError(webhookData.operation_id, dbError instanceof Error ? dbError.message : 'Database error', undefined, invoiceId);
                        }
                    }
                    else {
                    }
                    // Отвечаем 200 OK - критически важно для ЮMoney
                    res.json({
                        success: true,
                        message: `${webhookData.notification_type} payment received`,
                        amount: webhookData.amount,
                        currency: webhookData.currency,
                        operation_id: webhookData.operation_id,
                        label: webhookData.label,
                        invoice_found: !!invoiceId
                    });
                    return;
                }
                // Тестовое уведомление
                if (webhookData.test_notification === true) {
                    res.json({
                        success: true,
                        message: 'Test notification received',
                        notification_type: webhookData.notification_type,
                        amount: webhookData.amount,
                        operation_id: webhookData.operation_id
                    });
                    return;
                }
                // Неизвестный тип уведомления от ЮMoney
                res.json({
                    success: true,
                    message: 'Unknown YuMoney notification type',
                    notification_type: webhookData.notification_type
                });
                return;
            }
            // Если это НЕ уведомление от ЮMoney, но есть label - возможно от Яндекс.Форм
            if (webhookData.label && webhookData.label.startsWith('INV-')) {
                // Ищем счет по метке
                let invoiceId = null;
                invoiceId = await findInvoiceByLabel(webhookData.label);
                if (invoiceId) {
                    try {
                        // Обновляем статус счета
                        const paymentData = {
                            invoiceId,
                            paymentId: `yandex-forms-${Date.now()}`,
                            amount: webhookData.amount,
                            currency: '643', // RUB
                            paymentMethod: 'Yandex Forms',
                            paymentDate: new Date().toISOString(),
                            operationId: `yandex-forms-${Date.now()}`
                        };
                        const result = await updateInvoicePaymentStatus(paymentData);
                        if (result.success) {
                            res.json({
                                success: true,
                                message: 'Payment processed successfully from Yandex Forms',
                                invoice_id: invoiceId,
                                amount: webhookData.amount
                            });
                            return;
                        }
                        else {
                            console.error(`❌ Не удалось обновить счет ${invoiceId}:`, result.error);
                            res.status(500).json({
                                success: false,
                                error: 'Failed to update invoice'
                            });
                            return;
                        }
                    }
                    catch (dbError) {
                        console.error(`❌ Ошибка обработки платежа от Яндекс.Форм:`, dbError);
                        res.status(500).json({
                            success: false,
                            error: 'Internal server error'
                        });
                        return;
                    }
                }
                else {
                    res.status(404).json({
                        success: false,
                        error: 'Invoice not found',
                        label: webhookData.label
                    });
                    return;
                }
            }
            // Неизвестный формат form-urlencoded данных
            res.json({
                success: true,
                message: 'Unknown form-urlencoded format'
            });
            return;
        }
        // Если это JSON данные (платежи через форму)
        if (req.headers['content-type']?.includes('application/json')) {
            const jsonData = req.body;
            if ('event' in jsonData && jsonData.event === 'payment.succeeded') {
                const payment = jsonData.object;
                if (!payment) {
                    console.error('❌ Объект платежа не найден');
                    res.status(400).json({
                        success: false,
                        error: 'Missing payment object'
                    });
                    return;
                }
                const metadata = payment.metadata || {};
                const invoiceId = metadata.invoice_id;
                if (!invoiceId) {
                    console.error('❌ invoice_id не найден в metadata платежа');
                    res.status(400).json({
                        success: false,
                        error: 'Missing invoice_id in payment metadata'
                    });
                    return;
                }
                try {
                    // Обновляем статус счета
                    const paymentData = {
                        invoiceId,
                        paymentId: payment.id,
                        amount: payment.amount.value,
                        currency: payment.amount.currency,
                        paymentMethod: payment.payment_method.type,
                        paymentDate: payment.captured_at || payment.created_at,
                        operationId: payment.id
                    };
                    const result = await updateInvoicePaymentStatus(paymentData);
                    if (result.success) {
                        // Отправляем уведомления
                        try {
                            const invoiceResult = await pool.query('SELECT user_id FROM invoices WHERE id = $1', [invoiceId]);
                            if (invoiceResult.rows.length > 0) {
                                const userId = invoiceResult.rows[0].user_id;
                                await sendPaymentSuccessNotification(userId, invoiceId, payment.amount.value, payment.payment_method.type);
                            }
                        }
                        catch (notifyError) {
                            console.error('❌ Ошибка отправки уведомления:', notifyError);
                        }
                        res.json({
                            success: true,
                            message: 'Payment processed successfully',
                            invoice_id: invoiceId,
                            payment_id: payment.id
                        });
                    }
                    else {
                        console.error(`❌ Не удалось обновить счет ${invoiceId}:`, result.error);
                        await handlePaymentError(payment.id, result.error || 'Failed to update invoice', undefined, invoiceId);
                        res.status(500).json({
                            success: false,
                            error: 'Failed to update invoice'
                        });
                    }
                }
                catch (dbError) {
                    console.error(`❌ Ошибка обработки платежа:`, dbError);
                    await handlePaymentError(payment.id, dbError instanceof Error ? dbError.message : 'Database error', undefined, invoiceId);
                    res.status(500).json({
                        success: false,
                        error: 'Internal server error'
                    });
                }
                return;
            }
            // Неизвестный JSON формат
            res.status(200).json({
                success: true,
                message: 'Unknown JSON webhook format'
            });
            return;
        }
        // Неизвестный формат webhook'а
        res.status(200).json({
            success: true,
            message: 'Unknown webhook format'
        });
    }
    catch (error) {
        console.error('❌ Ошибка обработки webhook\'а от ЮMoney:', error);
        // Обрабатываем ошибку с созданием записи о повторной попытке
        try {
            const operationId = req.body?.operation_id || req.body?.object?.id || 'unknown';
            await handlePaymentError(operationId, error instanceof Error ? error.message : 'Unknown error');
        }
        catch (retryError) {
            console.error('❌ Критическая ошибка при обработке ошибки:', retryError);
        }
        res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
});
// Диагностический endpoint
router.get('/debug', async (req, res) => {
    try {
        const result = await pool.query('SELECT id, payment_label, status FROM invoices ORDER BY created_at DESC LIMIT 3');
        res.json({
            success: true,
            message: 'Debug endpoint working',
            invoices: result.rows
        });
    }
    catch (error) {
        console.error('❌ Ошибка диагностики:', error);
        res.status(500).json({
            success: false,
            error: 'Debug error'
        });
    }
});
// Тестовый endpoint для проверки findInvoiceByLabel
router.get('/test-find/:label', async (req, res) => {
    try {
        const { label } = req.params;
        if (!label) {
            return res.status(400).json({
                success: false,
                error: 'Label parameter is required'
            });
        }
        const invoiceId = await findInvoiceByLabel(label);
        return res.json({
            success: true,
            label: label,
            invoiceId: invoiceId,
            found: !!invoiceId
        });
    }
    catch (error) {
        console.error('❌ Ошибка тестового поиска:', error);
        return res.status(500).json({
            success: false,
            error: 'Test find error'
        });
    }
});
export default router;
//# sourceMappingURL=payment-webhook.js.map