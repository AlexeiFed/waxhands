declare const seedData: () => Promise<void>;
declare const runSeed: () => Promise<void>;
export { seedData, runSeed };
//# sourceMappingURL=seed.d.ts.map