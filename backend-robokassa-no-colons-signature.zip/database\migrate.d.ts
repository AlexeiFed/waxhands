declare const createTables: () => Promise<void>;
declare const dropTables: () => Promise<void>;
declare const runMigrations: () => Promise<void>;
export { createTables, dropTables, runMigrations };
//# sourceMappingURL=migrate.d.ts.map