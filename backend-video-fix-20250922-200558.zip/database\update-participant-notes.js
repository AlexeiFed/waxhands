/**
 * @file: update-participant-notes.js
 * @description: Миграция для обновления примечаний участников из workshop_registrations
 * @created: 2025-01-09
 */
import pool from '../../database/connection.js';
async function updateParticipantNotes() {
    try {
        // Получаем все мастер-классы с участниками
        const masterClassesResult = await pool.query(`
            SELECT id, participants 
            FROM master_class_events 
            WHERE participants IS NOT NULL AND jsonb_array_length(participants) > 0
        `);
        let updatedCount = 0;
        for (const masterClass of masterClassesResult.rows) {
            const participants = masterClass.participants;
            let hasUpdates = false;
            // Обновляем каждого участника
            const updatedParticipants = await Promise.all(participants.map(async (participant) => {
                // Проверяем, есть ли технические примечания
                if (participant.notes &&
                    (participant.notes.includes('Групповая регистрация') ||
                        participant.notes.includes('Детская регистрация') ||
                        participant.notes.includes('Счет:') ||
                        participant.notes.includes('Родитель:'))) {
                    // Ищем реальные примечания в workshop_registrations
                    try {
                        const registrationResult = await pool.query(`
                            SELECT notes 
                            FROM workshop_registrations 
                            WHERE user_id = $1 AND workshop_id = $2 AND notes IS NOT NULL AND notes != ''
                        `, [participant.childId, masterClass.id]);
                        if (registrationResult.rows.length > 0) {
                            const realNotes = registrationResult.rows[0].notes;
                            hasUpdates = true;
                            return {
                                ...participant,
                                notes: realNotes
                            };
                        }
                        else {
                            hasUpdates = true;
                            return {
                                ...participant,
                                notes: null
                            };
                        }
                    }
                    catch (error) {
                        console.error(`❌ Ошибка поиска примечаний для ${participant.childName}:`, error);
                        return participant;
                    }
                }
                return participant;
            }));
            // Если есть изменения, обновляем мастер-класс
            if (hasUpdates) {
                await pool.query(`
                    UPDATE master_class_events 
                    SET participants = $1, updated_at = CURRENT_TIMESTAMP
                    WHERE id = $2
                `, [JSON.stringify(updatedParticipants), masterClass.id]);
                updatedCount++;
            }
        }
    }
    catch (error) {
        console.error('❌ Ошибка при обновлении примечаний участников:', error);
        throw error;
    }
}
// Запускаем миграцию
updateParticipantNotes()
    .then(() => {
    process.exit(0);
})
    .catch((error) => {
    console.error('❌ Ошибка миграции:', error);
    process.exit(1);
});
//# sourceMappingURL=update-participant-notes.js.map