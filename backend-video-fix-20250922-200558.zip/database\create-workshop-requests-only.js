/**
 * @file: backend/src/database/create-workshop-requests-only.ts
 * @description: Скрипт для создания только таблицы workshop_requests
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */
import pool from './connection.js';
export async function createWorkshopRequestsTableOnly() {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        // Создание таблицы заявок на мастер-классы
        await client.query(`
            CREATE TABLE IF NOT EXISTS workshop_requests (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                parent_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                school_name VARCHAR(255) NOT NULL,
                class_group VARCHAR(100) NOT NULL,
                desired_date DATE NOT NULL,
                notes TEXT,
                status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
                created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                admin_notes TEXT,
                admin_id UUID REFERENCES users(id) ON DELETE SET NULL
            )
        `);
        // Создаем индексы для workshop_requests
        await client.query(`
            CREATE INDEX IF NOT EXISTS idx_workshop_requests_parent_id ON workshop_requests(parent_id)
        `);
        await client.query(`
            CREATE INDEX IF NOT EXISTS idx_workshop_requests_status ON workshop_requests(status)
        `);
        await client.query(`
            CREATE INDEX IF NOT EXISTS idx_workshop_requests_created_at ON workshop_requests(created_at)
        `);
        await client.query('COMMIT');
    }
    catch (error) {
        await client.query('ROLLBACK');
        console.error('❌ Error creating workshop_requests table:', error);
        throw error;
    }
    finally {
        client.release();
    }
}
// Запуск если файл выполняется напрямую
if (process.argv[1] && process.argv[1].includes('create-workshop-requests-only.ts')) {
    createWorkshopRequestsTableOnly()
        .then(() => {
        process.exit(0);
    })
        .catch((error) => {
        console.error('❌ Failed to create workshop_requests table:', error);
        process.exit(1);
    });
}
export default createWorkshopRequestsTableOnly;
//# sourceMappingURL=create-workshop-requests-only.js.map