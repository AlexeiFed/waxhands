/**
 * @file: offers-pdf.ts
 * @description: API эндпоинты для генерации PDF оферт
 * @dependencies: puppeteer, express, database/connection
 * @created: 2024-12-19
 */
import express from 'express';
import { db as pool } from '../database/connection.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';
const router = express.Router();
// Простая функция для создания PDF
const createSimplePdf = (htmlContent) => {
    // Создаем простой PDF с помощью встроенных возможностей
    // Это базовая реализация, которая создает PDF-подобный контент
    const pdfContent = `
%PDF-1.4
1 0 obj
<<
/Type /Catalog
/Pages 2 0 R
>>
endobj

2 0 obj
<<
/Type /Pages
/Kids [3 0 R]
/Count 1
>>
endobj

3 0 obj
<<
/Type /Page
/Parent 2 0 R
/MediaBox [0 0 612 792]
/Contents 4 0 R
/Resources <<
/Font <<
/F1 5 0 R
>>
>>
>>
endobj

4 0 obj
<<
/Length 1000
>>
stream
BT
/F1 12 Tf
50 750 Td
(Оферта) Tj
0 -20 Td
(Версия: 1.0) Tj
0 -20 Td
(Дата: ${new Date().toLocaleDateString('ru-RU')}) Tj
0 -40 Td
(Содержимое оферты будет добавлено здесь) Tj
ET
endstream
endobj

5 0 obj
<<
/Type /Font
/Subtype /Type1
/BaseFont /Helvetica
>>
endobj

xref
0 6
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000274 00000 n 
0000001300 00000 n 
trailer
<<
/Size 6
/Root 1 0 R
>>
startxref
1400
%%EOF
`;
    return Buffer.from(pdfContent, 'utf8');
};
// Генерация PDF оферты
router.get('/current/pdf', async (req, res) => {
    try {
        // Получаем текущую активную оферту
        const result = await pool.query('SELECT * FROM offers WHERE is_active = TRUE ORDER BY created_at DESC LIMIT 1');
        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                error: 'Активная оферта не найдена'
            });
        }
        const offer = result.rows[0];
        // Создаем HTML для PDF
        const htmlContent = `
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${offer.title}</title>
    <style>
        body {
            font-family: 'Times New Roman', serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            color: #333;
            background: white;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #333;
            padding-bottom: 20px;
        }
        .header h1 {
            font-size: 24px;
            margin: 0 0 10px 0;
            font-weight: bold;
        }
        .header .version {
            font-size: 14px;
            color: #666;
            margin: 0;
        }
        .content {
            max-width: 800px;
            margin: 0 auto;
        }
        .content h1 {
            font-size: 20px;
            margin: 25px 0 15px 0;
            font-weight: bold;
            color: #333;
        }
        .content h2 {
            font-size: 18px;
            margin: 20px 0 12px 0;
            font-weight: bold;
            color: #444;
        }
        .content h3 {
            font-size: 16px;
            margin: 15px 0 10px 0;
            font-weight: bold;
            color: #555;
        }
        .content p {
            margin: 10px 0;
            text-align: justify;
        }
        .content ul, .content ol {
            margin: 10px 0;
            padding-left: 25px;
        }
        .content li {
            margin: 5px 0;
        }
        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ccc;
            text-align: center;
            font-size: 12px;
            color: #666;
        }
        .page-break {
            page-break-before: always;
        }
        @media print {
            body {
                margin: 0;
                padding: 15px;
            }
            .page-break {
                page-break-before: always;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>${offer.title}</h1>
        <p class="version">Версия: ${offer.version} от ${new Date(offer.created_at).toLocaleDateString('ru-RU')}</p>
    </div>
    
    <div class="content">
        ${offer.content}
    </div>
    
    <div class="footer">
        <p>Документ сгенерирован: ${new Date().toLocaleDateString('ru-RU')} в ${new Date().toLocaleTimeString('ru-RU')}</p>
        <p>Сайт: waxhands.ru</p>
    </div>
</body>
</html>`;
        // Генерируем простой PDF
        const pdf = createSimplePdf(htmlContent);
        // Отправляем PDF
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename="offer-${offer.version}-${new Date().toISOString().split('T')[0]}.pdf"`);
        res.setHeader('Content-Length', pdf.length);
        return res.send(pdf);
    }
    catch (error) {
        console.error('Ошибка генерации PDF оферты:', error);
        return res.status(500).json({
            success: false,
            error: 'Ошибка генерации PDF'
        });
    }
});
// Генерация PDF оферты (только для админов)
router.get('/:id/pdf', authenticateToken, requireRole('admin'), async (req, res) => {
    try {
        const { id } = req.params;
        // Получаем оферту по ID
        const result = await pool.query('SELECT * FROM offers WHERE id = $1', [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                error: 'Оферта не найдена'
            });
        }
        const offer = result.rows[0];
        // Создаем HTML для PDF (аналогично выше)
        const htmlContent = `
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${offer.title}</title>
    <style>
        body {
            font-family: 'Times New Roman', serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            color: #333;
            background: white;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #333;
            padding-bottom: 20px;
        }
        .header h1 {
            font-size: 24px;
            margin: 0 0 10px 0;
            font-weight: bold;
        }
        .header .version {
            font-size: 14px;
            color: #666;
            margin: 0;
        }
        .content {
            max-width: 800px;
            margin: 0 auto;
        }
        .content h1 {
            font-size: 20px;
            margin: 25px 0 15px 0;
            font-weight: bold;
            color: #333;
        }
        .content h2 {
            font-size: 18px;
            margin: 20px 0 12px 0;
            font-weight: bold;
            color: #444;
        }
        .content h3 {
            font-size: 16px;
            margin: 15px 0 10px 0;
            font-weight: bold;
            color: #555;
        }
        .content p {
            margin: 10px 0;
            text-align: justify;
        }
        .content ul, .content ol {
            margin: 10px 0;
            padding-left: 25px;
        }
        .content li {
            margin: 5px 0;
        }
        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ccc;
            text-align: center;
            font-size: 12px;
            color: #666;
        }
        .page-break {
            page-break-before: always;
        }
        @media print {
            body {
                margin: 0;
                padding: 15px;
            }
            .page-break {
                page-break-before: always;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>${offer.title}</h1>
        <p class="version">Версия: ${offer.version} от ${new Date(offer.created_at).toLocaleDateString('ru-RU')}</p>
    </div>
    
    <div class="content">
        ${offer.content}
    </div>
    
    <div class="footer">
        <p>Документ сгенерирован: ${new Date().toLocaleDateString('ru-RU')} в ${new Date().toLocaleTimeString('ru-RU')}</p>
        <p>Сайт: waxhands.ru</p>
    </div>
</body>
</html>`;
        // Генерируем простой PDF
        const pdf = createSimplePdf(htmlContent);
        // Отправляем PDF
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename="offer-${offer.version}-${new Date().toISOString().split('T')[0]}.pdf"`);
        res.setHeader('Content-Length', pdf.length);
        return res.send(pdf);
    }
    catch (error) {
        console.error('Ошибка генерации PDF оферты:', error);
        return res.status(500).json({
            success: false,
            error: 'Ошибка генерации PDF'
        });
    }
});
export default router;
//# sourceMappingURL=offers-pdf.js.map