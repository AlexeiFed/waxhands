/**
 * @file: robokassa-sync.ts
 * @description: Endpoint для синхронизации статусов счетов с Robokassa
 * @dependencies: express, robokassaService, database
 * @created: 2025-11-12
 */
declare const router: import("@types/express-serve-static-core/index.js").Router;
export default router;
//# sourceMappingURL=robokassa-sync.d.ts.map