/**
 * @file: payments.ts
 * @description: API маршруты для работы с платежами
 * @dependencies: Router, pool, authenticateToken
 * @created: 2025-01-26
 */
declare const router: import("@types/express-serve-static-core/index.js").Router;
export default router;
//# sourceMappingURL=payments.d.ts.map