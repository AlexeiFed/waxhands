/**
 * @file: add-refund-email-field.ts
 * @description: Добавляет поле refund_email в таблицу invoices
 * @created: 2025-11-10
 */
export {};
//# sourceMappingURL=add-refund-email-field.d.ts.map