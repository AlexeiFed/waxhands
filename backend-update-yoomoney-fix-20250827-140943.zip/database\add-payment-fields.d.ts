/**
 * @file: add-payment-fields.ts
 * @description: Миграция для добавления полей платежа в таблицу invoices
 * @dependencies: pool
 * @created: 2024-12-19
 */
declare const addPaymentFields: () => Promise<void>;
export default addPaymentFields;
//# sourceMappingURL=add-payment-fields.d.ts.map