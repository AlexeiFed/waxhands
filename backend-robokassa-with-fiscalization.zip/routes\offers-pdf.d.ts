/**
 * @file: offers-pdf.ts
 * @description: API эндпоинты для генерации PDF оферт
 * @dependencies: puppeteer, express, database/connection
 * @created: 2024-12-19
 */
declare const router: import("@types/express-serve-static-core/index.js").Router;
export default router;
//# sourceMappingURL=offers-pdf.d.ts.map