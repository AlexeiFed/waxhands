import { Request, Response } from 'express';
export declare const getMasterClassEventById: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=masterClassesFixed.d.ts.map