/**
 * @file: PaymentFactory.ts
 * @description: Фабрика для платежного провайдера Robokassa
 * @dependencies: IPaymentProvider, RobokassaProvider
 * @created: 2025-10-16
 */
import { IPaymentProvider } from './interfaces/IPaymentProvider.js';
import { RobokassaProvider } from './providers/RobokassaProvider.js';
/**
 * Фабрика платежных провайдеров (только Robokassa)
 */
export declare class PaymentFactory {
    private static instance;
    private currentProvider;
    private constructor();
    /**
     * Получает единственный экземпляр фабрики (Singleton)
     */
    static getInstance(): PaymentFactory;
    /**
     * Получает текущий платежный провайдер (всегда Robokassa)
     */
    getProvider(): IPaymentProvider;
    /**
     * Получает Robokassa провайдер
     */
    getRobokassaProvider(): RobokassaProvider;
}
/**
 * Экспортируем единственный экземпляр фабрики
 */
export declare const paymentFactory: PaymentFactory;
/**
 * Вспомогательная функция для получения текущего провайдера
 */
export declare function getPaymentProvider(): IPaymentProvider;
//# sourceMappingURL=PaymentFactory.d.ts.map