/**
 * @file: paymentSettings.ts
 * @description: Работа с таблицей payment_settings
 * @dependencies: pg connection pool
 * @created: 2025-11-09
 */
export interface PaymentSettingsRow {
    id: number;
    is_enabled: boolean;
    updated_at: string;
}
export declare const getPaymentSettings: () => Promise<PaymentSettingsRow>;
export declare const updatePaymentSettings: (isEnabled: boolean) => Promise<PaymentSettingsRow>;
//# sourceMappingURL=paymentSettings.d.ts.map