/**
 * @file: add-robokassa-opkey.ts
 * @description: Миграция для добавления поля robokassa_op_key в таблицу invoices
 * @dependencies: database/connection.ts
 * @created: 2025-10-17
 */
declare function addRobokassaOpKey(): Promise<void>;
export default addRobokassaOpKey;
//# sourceMappingURL=add-robokassa-opkey.d.ts.map