/**
 * @file: check-service-data.ts
 * @description: Проверка данных в таблице services
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */
export declare const checkServiceData: () => Promise<void>;
//# sourceMappingURL=check-service-data.d.ts.map