/**
 * @file: check-tables.ts
 * @description: Проверка существующих таблиц в БД
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */
export declare const checkTables: () => Promise<void>;
//# sourceMappingURL=check-tables.d.ts.map