export {};
//# sourceMappingURL=update-participant-notes.d.ts.map