/**
 * @file: add-city-field.ts
 * @description: Миграция для добавления поля city в таблицу master_class_events
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */
export declare const addCityField: () => Promise<void>;
//# sourceMappingURL=add-city-field.d.ts.map