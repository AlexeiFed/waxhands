/**
 * @file: payment.ts
 * @description: Универсальные маршруты для работы с платежными системами
 * @dependencies: paymentController.ts, authMiddleware.ts
 * @created: 2025-10-16
 */
declare const router: import("@types/express-serve-static-core/index.js").Router;
export default router;
//# sourceMappingURL=payment.d.ts.map