/**
 * @file: PaymentFactory.ts
 * @description: Фабрика для выбора платежного провайдера (Robokassa, FreeKassa и др.)
 * @dependencies: IPaymentProvider, RobokassaProvider, FreekassaProvider
 * @created: 2025-10-16
 */
import { IPaymentProvider } from './interfaces/IPaymentProvider.js';
import { RobokassaProvider } from './providers/RobokassaProvider.js';
import { FreekassaProvider } from './providers/FreekassaProvider.js';
type PaymentProviderType = 'robokassa' | 'freekassa';
/**
 * Фабрика платежных провайдеров
 * Позволяет легко переключаться между различными платежными системами через переменную окружения
 */
export declare class PaymentFactory {
    private static instance;
    private currentProvider;
    private providerType;
    private constructor();
    /**
     * Получает единственный экземпляр фабрики (Singleton)
     */
    static getInstance(): PaymentFactory;
    /**
     * Создает экземпляр провайдера по типу
     */
    private createProvider;
    /**
     * Получает текущий платежный провайдер
     */
    getProvider(): IPaymentProvider;
    /**
     * Получает тип текущего провайдера
     */
    getProviderType(): PaymentProviderType;
    /**
     * Переключает провайдер (используется для тестирования или динамического переключения)
     */
    switchProvider(type: PaymentProviderType): void;
    /**
     * Проверяет, является ли текущий провайдер Robokassa
     */
    isRobokassa(): boolean;
    /**
     * Проверяет, является ли текущий провайдер FreeKassa
     */
    isFreekassa(): boolean;
    /**
     * Получает специфичный провайдер (для обратной совместимости)
     * @deprecated Используйте getProvider() для общих операций
     */
    getRobokassaProvider(): RobokassaProvider | null;
    /**
     * Получает специфичный провайдер FreeKassa (для обратной совместимости)
     * @deprecated Используйте getProvider() для общих операций
     */
    getFreekassaProvider(): FreekassaProvider | null;
}
/**
 * Экспортируем единственный экземпляр фабрики
 */
export declare const paymentFactory: PaymentFactory;
/**
 * Вспомогательная функция для получения текущего провайдера
 */
export declare function getPaymentProvider(): IPaymentProvider;
export {};
//# sourceMappingURL=PaymentFactory.d.ts.map