/**
 * @file: IPaymentProvider.ts
 * @description: Интерфейс для платежных провайдеров (Robokassa, FreeKassa и др.)
 * @dependencies: types/index.ts
 * @created: 2025-10-16
 */
export {};
//# sourceMappingURL=IPaymentProvider.js.map