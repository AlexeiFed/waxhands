/**
 * @file: update-dates.ts
 * @description: Обновляет даты мастер-классов на будущие
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */
declare const updateDates: () => Promise<void>;
export { updateDates };
//# sourceMappingURL=update-dates.d.ts.map