/**
 * @file: add-refund-reason-field.ts
 * @description: Добавляет поле refund_reason в таблицу invoices
 * @dependencies: pool
 * @created: 2025-01-27
 */
declare function addRefundReasonField(): Promise<void>;
export default addRefundReasonField;
//# sourceMappingURL=add-refund-reason-field.d.ts.map