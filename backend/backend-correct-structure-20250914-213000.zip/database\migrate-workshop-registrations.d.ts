/**
 * @file: migrate-workshop-registrations.ts
 * @description: Миграция для создания таблицы записей на мастер-классы
 * @dependencies: database connection
 * @created: 2024-12-19
 */
export declare const migrateWorkshopRegistrations: () => Promise<void>;
//# sourceMappingURL=migrate-workshop-registrations.d.ts.map