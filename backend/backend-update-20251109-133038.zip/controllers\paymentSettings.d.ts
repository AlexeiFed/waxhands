/**
 * @file: paymentSettings.ts
 * @description: Контроллеры для управления настройками оплаты
 * @dependencies: express, paymentSettings database module
 * @created: 2025-11-09
 */
import { Request, Response } from 'express';
export declare const getPaymentSettingsController: (req: Request, res: Response) => Promise<void>;
export declare const updatePaymentSettingsController: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=paymentSettings.d.ts.map