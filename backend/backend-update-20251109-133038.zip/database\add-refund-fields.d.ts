/**
 * @file: add-refund-fields.ts
 * @description: Миграция для добавления полей возврата в таблицу invoices
 * @dependencies: pool
 * @created: 2025-01-26
 */
declare const addRefundFields: () => Promise<void>;
export default addRefundFields;
//# sourceMappingURL=add-refund-fields.d.ts.map