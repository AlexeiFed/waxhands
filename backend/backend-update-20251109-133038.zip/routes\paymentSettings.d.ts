/**
 * @file: paymentSettings.ts
 * @description: Маршруты для управления настройками оплаты Robokassa
 * @dependencies: express, auth middleware, paymentSettingsController
 * @created: 2025-11-09
 */
declare const router: import("@types/express-serve-static-core/index.js").Router;
export default router;
//# sourceMappingURL=paymentSettings.d.ts.map