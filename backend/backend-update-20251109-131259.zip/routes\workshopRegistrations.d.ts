/**
 * @file: workshopRegistrations.ts
 * @description: Маршруты для API записи на мастер-классы
 * @dependencies: workshopRegistrations controller, auth middleware
 * @created: 2024-12-19
 */
declare const router: import("@types/express-serve-static-core/index.js").Router;
export default router;
//# sourceMappingURL=workshopRegistrations.d.ts.map