/**
 * @file: admin.ts
 * @description: Контроллер для административных функций
 * @dependencies: pool, AuthenticatedRequest
 * @created: 2025-01-27
 */
import { Request, Response } from 'express';
/**
 * Получает список всех возвратов
 */
export declare const getRefunds: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=admin.d.ts.map