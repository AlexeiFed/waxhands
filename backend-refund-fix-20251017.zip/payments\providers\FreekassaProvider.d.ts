/**
 * @file: FreekassaProvider.ts
 * @description: Провайдер для интеграции с FreeKassa
 * @dependencies: IPaymentProvider, crypto
 * @created: 2025-10-16
 */
import { IPaymentProvider, PaymentInvoiceData, PaymentInvoiceResponse, PaymentNotification, PaymentRefundRequest, PaymentRefundResponse, PaymentRefundStatus } from '../interfaces/IPaymentProvider.js';
export declare class FreekassaProvider implements IPaymentProvider {
    readonly providerName = "FreeKassa";
    private config;
    constructor();
    /**
     * Создает подпись для платежа (платежная форма)
     * Формат согласно документации: MD5(merchantId:amount:secretWord1:currency:orderId)
     */
    private createPaymentSignature;
    /**
     * Создает подпись для API запросов
     * Формат согласно документации: HMAC-SHA256(sortedValues, apiKey)
     */
    private createApiSignature;
    /**
     * Создает подпись для проверки уведомления (webhook)
     * Формат согласно документации: MD5(MERCHANT_ID:AMOUNT:secretWord2:MERCHANT_ORDER_ID)
     */
    private verifyWebhookSignature;
    /**
     * Создает счет на оплату через FreeKassa
     */
    createInvoice(data: PaymentInvoiceData): Promise<PaymentInvoiceResponse>;
    /**
     * Проверяет подпись уведомления от FreeKassa (webhook)
     * Параметры: MERCHANT_ID, AMOUNT, intid, MERCHANT_ORDER_ID, SIGN
     */
    verifyNotification(notification: PaymentNotification): boolean;
    /**
     * Проверяет подпись уведомления об успешной оплате (SuccessURL)
     * Используется та же логика, что и для webhook
     */
    verifySuccessNotification(notification: PaymentNotification): boolean;
    /**
     * Создает возврат средств через FreeKassa API
     * Используется POST /orders/refund согласно документации
     */
    createRefund?(data: PaymentRefundRequest): Promise<PaymentRefundResponse>;
    /**
     * Получает статус возврата через FreeKassa API
     * Используется GET /orders согласно документации (проверка статуса по order_id)
     */
    getRefundStatus?(requestId: string): Promise<PaymentRefundStatus | null>;
    /**
     * Проверяет возможность возврата для даты мастер-класса
     * Возврат возможен только за 3 часа до мастер-класса
     */
    isRefundAvailable(workshopDate: string): boolean;
    /**
     * Проверяет, доступна ли оплата для пользователя
     * FreeKassa доступна для всех пользователей
     */
    isPaymentAvailable(userData: {
        surname?: string;
        phone?: string;
    }): boolean;
    /**
     * FreeKassa не использует OpKey для возвратов
     */
    getOpKeyForRefund?(invoiceId: string): Promise<string | null>;
}
export declare const freekassaProvider: FreekassaProvider;
//# sourceMappingURL=FreekassaProvider.d.ts.map