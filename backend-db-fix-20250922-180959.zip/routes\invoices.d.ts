/**
 * @file: invoices.ts
 * @description: Маршруты для API счетов мастер-классов
 * @dependencies: controllers/invoices.ts, middleware/auth.ts
 * @created: 2024-12-19
 */
declare const router: import("@types/express-serve-static-core/index.js").Router;
export default router;
//# sourceMappingURL=invoices.d.ts.map