/**
 * @file: check-schools.ts
 * @description: Скрипт для проверки таблицы schools и данных в ней
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */
import pool from './connection.js';
const checkSchools = async () => {
    const client = await pool.connect();
    try {
        // Проверяем структуру таблицы schools
        const schemaResult = await client.query(`
            SELECT column_name, data_type, is_nullable, column_default
            FROM information_schema.columns 
            WHERE table_name = 'schools'
            ORDER BY ordinal_position
        `);
        schemaResult.rows.forEach(row => {
        });
        // Проверяем количество записей
        const countResult = await client.query(`SELECT COUNT(*) FROM schools`);
        // Проверяем образцы данных
        if (parseInt(countResult.rows[0].count) > 0) {
            const dataResult = await client.query(`
                SELECT id, name, address, classes
                FROM schools 
                LIMIT 5
            `);
            dataResult.rows.forEach((row, index) => {
            });
        }
        // Проверяем, есть ли школы с адресами
        const addressResult = await client.query(`
            SELECT COUNT(*) 
            FROM schools 
            WHERE address IS NOT NULL AND address != ''
        `);
        // Проверяем, есть ли школы с классами
        const classesResult = await client.query(`
            SELECT COUNT(*) 
            FROM schools 
            WHERE classes IS NOT NULL AND array_length(classes, 1) > 0
        `);
    }
    catch (error) {
        console.error('❌ Ошибка при проверке школ:', error);
        throw error;
    }
    finally {
        client.release();
    }
};
// Запуск проверки, если файл выполняется напрямую
checkSchools()
    .then(() => {
    process.exit(0);
})
    .catch((error) => {
    console.error('❌ Ошибка проверки школ:', error);
    process.exit(1);
});
export { checkSchools };
//# sourceMappingURL=check-schools.js.map