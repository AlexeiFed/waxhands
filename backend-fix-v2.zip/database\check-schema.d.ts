/**
 * @file: check-schema.ts
 * @description: Скрипт для проверки структуры таблицы master_class_events
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */
declare const checkSchema: () => Promise<void>;
export { checkSchema };
//# sourceMappingURL=check-schema.d.ts.map