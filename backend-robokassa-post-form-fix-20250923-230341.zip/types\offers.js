/**
 * @file: offers.ts
 * @description: Типы для системы оферт
 * @dependencies: none
 * @created: 2024-12-19
 */
export {};
//# sourceMappingURL=offers.js.map