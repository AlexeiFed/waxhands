export default cleanBlobUrls;
declare function cleanBlobUrls(): Promise<void>;
//# sourceMappingURL=clean-blob-urls.d.ts.map