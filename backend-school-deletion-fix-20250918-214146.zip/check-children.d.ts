export {};
//# sourceMappingURL=check-children.d.ts.map