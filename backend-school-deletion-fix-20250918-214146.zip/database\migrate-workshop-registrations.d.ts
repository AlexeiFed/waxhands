export function migrateWorkshopRegistrations(): Promise<void>;
//# sourceMappingURL=migrate-workshop-registrations.d.ts.map