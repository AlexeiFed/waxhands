export function getWebSocketManager(): any;
export function setWebSocketManager(manager: any): void;
export function sendWebSocketNotification(notificationData: any): Promise<boolean>;
export function saveNotificationToDatabase(notificationData: any): Promise<boolean>;
export function sendPaymentSuccessNotification(userId: any, invoiceId: any, amount: any, paymentMethod: any): Promise<void>;
export function sendPaymentFailedNotification(userId: any, invoiceId: any, error: any): Promise<void>;
export function sendPaymentReceivedNotification(adminUserId: any, invoiceId: any, amount: any, sender: any): Promise<void>;
export function getUserNotifications(userId: any, limit?: number): Promise<any[]>;
export function markNotificationAsRead(notificationId: any, userId: any): Promise<boolean>;
export function sendInvoiceStatusUpdate(invoiceId: any, newStatus: any, userId: any): Promise<boolean>;
//# sourceMappingURL=notificationService.d.ts.map