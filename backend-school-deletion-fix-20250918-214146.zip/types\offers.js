export {};
//# sourceMappingURL=offers.js.map
//# sourceMappingURL=offers.js.map