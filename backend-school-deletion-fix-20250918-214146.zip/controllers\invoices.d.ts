export function createInvoice(req: any, res: any): Promise<void>;
export function getInvoices(req: any, res: any): Promise<void>;
export function getInvoiceById(req: any, res: any): Promise<void>;
export function updateInvoice(req: any, res: any): Promise<void>;
export function updateInvoiceStatus(req: any, res: any): Promise<void>;
export function getInvoicesByDate(req: any, res: any): Promise<void>;
export function deleteInvoice(req: any, res: any): Promise<void>;
export function syncAllInvoicesWithParticipants(req: any, res: any): Promise<void>;
//# sourceMappingURL=invoices.d.ts.map