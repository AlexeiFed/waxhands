export function checkWorkshopRequestsTable(): Promise<void>;
export default checkWorkshopRequestsTable;
//# sourceMappingURL=check-workshop-requests.d.ts.map