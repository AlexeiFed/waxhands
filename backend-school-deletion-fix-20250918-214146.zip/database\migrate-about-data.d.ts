export function migrateAboutData(): Promise<boolean>;
//# sourceMappingURL=migrate-about-data.d.ts.map