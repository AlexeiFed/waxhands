export class AboutController {
    static getContent(req: any, res: any): Promise<any>;
    static updateContent(req: any, res: any): Promise<any>;
    static getMedia(req: any, res: any): Promise<any>;
    static addMedia(req: any, res: any): Promise<any>;
    static updateMedia(req: any, res: any): Promise<any>;
    static deleteMedia(req: any, res: any): Promise<any>;
    static reorderMedia(req: any, res: any): Promise<any>;
}
//# sourceMappingURL=about.d.ts.map