export function getUsers(req: any, res: any): Promise<void>;
export function getUserById(req: any, res: any): Promise<void>;
export function updateUser(req: any, res: any): Promise<void>;
export function deleteUser(req: any, res: any): Promise<void>;
export function getChildrenByParentId(req: any, res: any): Promise<void>;
export function getCurrentUser(req: any, res: any): Promise<void>;
export function createUser(req: any, res: any): Promise<void>;
//# sourceMappingURL=users.d.ts.map