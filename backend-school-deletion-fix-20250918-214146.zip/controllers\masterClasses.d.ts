export function testFunction(req: any, res: any): Promise<void>;
export function getMasterClassEvents(req: any, res: any): Promise<void>;
export function getMasterClassEventByIdNew(req: any, res: any): Promise<void>;
export function getMasterClassEventById(req: any, res: any): Promise<void>;
export function createMasterClassEvent(req: any, res: any): Promise<void>;
export function createMultipleMasterClassEvents(req: any, res: any): Promise<void>;
export function updateMasterClassEvent(req: any, res: any): Promise<void>;
export function updateParticipantPaymentStatus(req: any, res: any): Promise<void>;
export function deleteMasterClassEvent(req: any, res: any): Promise<void>;
export function deleteSchoolMasterClasses(req: any, res: any): Promise<void>;
//# sourceMappingURL=masterClasses.d.ts.map