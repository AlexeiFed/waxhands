export function addAgeField(): Promise<void>;
//# sourceMappingURL=add-age-field.d.ts.map