export function createChatTables(): Promise<void>;
//# sourceMappingURL=create-chat-tables.d.ts.map