export function updateInvoicePaymentStatus(paymentData: any): Promise<{
    success: boolean;
    message: string;
    error: string;
    invoiceId?: never;
    paymentId?: never;
} | {
    success: boolean;
    message: string;
    invoiceId: any;
    paymentId: any;
    error?: never;
}>;
export function findInvoiceByLabel(label: any): Promise<any>;
export function findInvoiceBySender(sender: any): Promise<any>;
//# sourceMappingURL=paymentService.d.ts.map