export function addParentIdField(): Promise<void>;
//# sourceMappingURL=add-parent-id-field.d.ts.map