export default router;
declare const router: import("@types/express-serve-static-core").Router;
//# sourceMappingURL=privacy-policy.d.ts.map