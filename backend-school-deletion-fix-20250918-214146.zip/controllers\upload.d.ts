export function uploadFiles(req: any, res: any): Promise<void>;
//# sourceMappingURL=upload.d.ts.map