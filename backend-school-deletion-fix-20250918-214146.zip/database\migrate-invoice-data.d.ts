export default migrateInvoiceData;
declare function migrateInvoiceData(): Promise<void>;
//# sourceMappingURL=migrate-invoice-data.d.ts.map