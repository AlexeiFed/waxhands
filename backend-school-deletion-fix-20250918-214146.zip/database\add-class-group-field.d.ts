export function addClassGroupField(): Promise<void>;
//# sourceMappingURL=add-class-group-field.d.ts.map