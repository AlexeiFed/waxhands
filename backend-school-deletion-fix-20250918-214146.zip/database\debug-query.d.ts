export function debugQuery(): Promise<void>;
//# sourceMappingURL=debug-query.d.ts.map