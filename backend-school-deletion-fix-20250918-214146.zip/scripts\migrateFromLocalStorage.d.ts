export function migrateData(): Promise<void>;
export function runMigration(): Promise<void>;
//# sourceMappingURL=migrateFromLocalStorage.d.ts.map