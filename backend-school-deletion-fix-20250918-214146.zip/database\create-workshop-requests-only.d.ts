export function createWorkshopRequestsTableOnly(): Promise<void>;
export default createWorkshopRequestsTableOnly;
//# sourceMappingURL=create-workshop-requests-only.d.ts.map