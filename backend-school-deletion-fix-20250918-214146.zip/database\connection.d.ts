export const db: Pool;
export function testConnection(): Promise<boolean>;
export function query(text: any, params: any): Promise<import("pg").QueryArrayResult<any[]>>;
export default pool;
import { Pool } from 'pg';
declare const pool: Pool;
//# sourceMappingURL=connection.d.ts.map