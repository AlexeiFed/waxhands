export {};
//# sourceMappingURL=create-about-tables.d.ts.map