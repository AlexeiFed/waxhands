export const upload: multer.Multer;
export const uploadServiceFiles: import("@types/express").RequestHandler<import("@types/express-serve-static-core").ParamsDictionary, any, any, import("@types/qs").ParsedQs, Record<string, any>>;
import multer from 'multer';
//# sourceMappingURL=upload.d.ts.map