export function getUserWorkshopRegistrations(req: any, res: any): Promise<void>;
export function getWorkshopRegistrations(req: any, res: any): Promise<void>;
export function createWorkshopRegistration(req: any, res: any): Promise<any>;
export function createGroupWorkshopRegistration(req: any, res: any): Promise<void>;
export function updateRegistrationStatus(req: any, res: any): Promise<any>;
export function getWorkshopStats(workshopId: any): Promise<{
    workshopId: any;
    workshopTitle: any;
    totalRegistrations: number;
    confirmedRegistrations: number;
    pendingRegistrations: number;
    totalRevenue: any;
    maxParticipants: number;
    currentParticipants: number;
    isFull: boolean;
}>;
export function checkRegistration(req: any, res: any): Promise<void>;
export function removeParticipant(req: any, res: any): Promise<any>;
//# sourceMappingURL=workshopRegistrations.d.ts.map