export class ChatController {
    static createChat(req: any, res: any): Promise<any>;
    static getUserChats(req: any, res: any): Promise<void>;
    static getAllChats(req: any, res: any): Promise<any>;
    static getChatMessages(req: any, res: any): Promise<void>;
    static sendMessage(req: any, res: any): Promise<any>;
    static markAsRead(req: any, res: any): Promise<any>;
    static markMessageAsRead(req: any, res: any): Promise<any>;
    static updateChatStatus(req: any, res: any): Promise<any>;
    static getUnreadCount(req: any, res: any): Promise<void>;
}
//# sourceMappingURL=chat.d.ts.map