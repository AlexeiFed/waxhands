export function addCityField(): Promise<void>;
//# sourceMappingURL=add-city-field.d.ts.map