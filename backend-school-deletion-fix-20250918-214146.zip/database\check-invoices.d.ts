export function checkInvoices(): Promise<void>;
//# sourceMappingURL=check-invoices.d.ts.map