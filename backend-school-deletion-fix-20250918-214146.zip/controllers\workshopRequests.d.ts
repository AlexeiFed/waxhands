export class WorkshopRequestsController {
    static getAdminId(): Promise<any>;
    static createRequest(data: any): Promise<{
        success: boolean;
        error: string;
        data?: never;
        message?: never;
    } | {
        success: boolean;
        data: any;
        message: string;
        error?: never;
    }>;
    static getRequestById(id: any): Promise<any>;
    static getAllRequests(): Promise<{
        success: boolean;
        data: any[];
        error?: never;
    } | {
        success: boolean;
        error: string;
        data?: never;
    }>;
    static getRequestsByParentId(parentId: any): Promise<{
        success: boolean;
        data: any[];
        error?: never;
    } | {
        success: boolean;
        error: string;
        data?: never;
    }>;
    static updateRequestStatus(id: any, data: any): Promise<{
        success: boolean;
        error: string;
        data?: never;
        message?: never;
    } | {
        success: boolean;
        data: any;
        message: string;
        error?: never;
    }>;
    static deleteRequest(id: any): Promise<{
        success: boolean;
        data: boolean;
        message: string;
        error?: never;
    } | {
        success: boolean;
        error: string;
        data?: never;
        message?: never;
    }>;
    static getRequestsStats(): Promise<{
        success: boolean;
        data: {
            total: number;
            pending: number;
            approved: number;
            rejected: number;
        };
        error?: never;
    } | {
        success: boolean;
        error: string;
        data?: never;
    }>;
    static getRequestsStatsByParentId(parentId: any): Promise<{
        success: boolean;
        data: {
            total: number;
            pending: number;
            approved: number;
            rejected: number;
        };
        error?: never;
    } | {
        success: boolean;
        error: string;
        data?: never;
    }>;
}
//# sourceMappingURL=workshopRequests.d.ts.map