export {};
//# sourceMappingURL=offers.d.ts.map