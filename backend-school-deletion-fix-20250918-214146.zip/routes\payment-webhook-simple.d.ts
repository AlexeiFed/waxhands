export default router;
declare const router: import("@types/express-serve-static-core").Router;
//# sourceMappingURL=payment-webhook-simple.d.ts.map