export function createRetryAttempt(operationId: any, error: any, config?: {}): Promise<any>;
export function incrementRetryAttempt(retryId: any, error: any, config?: {}): Promise<boolean>;
export function markRetryAsFailed(retryId: any, reason: any): Promise<void>;
export function markRetryAsSuccess(retryId: any): Promise<void>;
export function getReadyRetryAttempts(): Promise<{
    id: any;
    operationId: any;
    attempt: any;
    maxAttempts: any;
    lastError: any;
    nextRetryAt: Date;
    createdAt: Date;
}[]>;
export function handlePaymentError(operationId: any, error: any, userId: any, invoiceId: any, config?: {}): Promise<void>;
export function cleanupOldRetryAttempts(daysOld?: number): Promise<number>;
//# sourceMappingURL=retryService.d.ts.map