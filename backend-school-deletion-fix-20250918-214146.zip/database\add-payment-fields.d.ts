export default addPaymentFields;
declare function addPaymentFields(): Promise<void>;
//# sourceMappingURL=add-payment-fields.d.ts.map