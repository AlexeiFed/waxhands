/**
 * @file: check-service-structure.ts
 * @description: Детальная проверка структуры таблицы services
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */
export declare const checkServiceStructure: () => Promise<void>;
//# sourceMappingURL=check-service-structure.d.ts.map