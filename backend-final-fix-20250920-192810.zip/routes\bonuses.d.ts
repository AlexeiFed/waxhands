/**
 * @file: bonuses.ts
 * @description: API маршруты для управления бонусами
 * @dependencies: express, database/connection, middleware/auth
 * @created: 2025-01-25
 */
declare const router: import("@types/express-serve-static-core/index.js").Router;
export default router;
//# sourceMappingURL=bonuses.d.ts.map