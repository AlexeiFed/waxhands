/**
 * @file: admin.ts
 * @description: Маршруты для административных функций
 * @dependencies: express, authenticateToken, adminController
 * @created: 2025-01-27
 */
declare const router: import("@types/express-serve-static-core/index.js").Router;
export default router;
//# sourceMappingURL=admin.d.ts.map