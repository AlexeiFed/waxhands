/**
 * @file: admin.ts
 * @description: Маршруты для административных функций
 * @dependencies: express, authenticateToken, adminController
 * @created: 2025-01-27
 */
import { Router } from 'express';
import { authenticateToken } from '../middleware/auth.js';
import { getRefunds } from '../controllers/admin.js';
const router = Router();
// Все маршруты требуют аутентификации
router.use(authenticateToken);
// Получение списка возвратов
router.get('/refunds', getRefunds);
export default router;
//# sourceMappingURL=admin.js.map