/**
 * @file: remove-city-field.ts
 * @description: Миграция для удаления поля city из таблицы master_class_events
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */
export declare const removeCityField: () => Promise<void>;
//# sourceMappingURL=remove-city-field.d.ts.map