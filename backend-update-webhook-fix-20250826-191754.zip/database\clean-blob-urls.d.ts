/**
 * @file: clean-blob-urls.ts
 * @description: Скрипт для очистки blob URL'ов из стилей и опций услуг
 * @created: 2024-12-19
 */
declare const cleanBlobUrls: () => Promise<void>;
export default cleanBlobUrls;
//# sourceMappingURL=clean-blob-urls.d.ts.map