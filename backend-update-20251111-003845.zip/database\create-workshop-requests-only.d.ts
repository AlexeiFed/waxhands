/**
 * @file: backend/src/database/create-workshop-requests-only.ts
 * @description: Скрипт для создания только таблицы workshop_requests
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */
export declare function createWorkshopRequestsTableOnly(): Promise<void>;
export default createWorkshopRequestsTableOnly;
//# sourceMappingURL=create-workshop-requests-only.d.ts.map