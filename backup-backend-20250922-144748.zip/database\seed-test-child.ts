/**
 * @file: seed-test-child.ts
 * @description: Скрипт для создания тестового ребенка
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */

import pool from './connection.js';

const seedTestChild = async () => {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        // Получаем первую школу
        const schoolsResult = await client.query('SELECT id, name FROM schools LIMIT 1');

        if (schoolsResult.rows.length === 0) {
            return;
        }

        const school = schoolsResult.rows[0];

        // Создаем или обновляем тестового ребенка
        const childId = 'd8748283-e5b9-4c0f-814c-bbe5b51ddd69'; // ID из консоли

        // Проверяем, существует ли пользователь
        const existingUser = await client.query('SELECT id FROM users WHERE id = $1', [childId]);

        if (existingUser.rows.length > 0) {
            // Обновляем существующего пользователя
            await client.query(`
        UPDATE users 
        SET school_id = $1, 
            school_name = $2, 
            class = $3,
            class_group = $4
        WHERE id = $5
      `, [school.id, school.name, '1А', '1А', childId]);
        } else {
            // Создаем нового пользователя
            await client.query(`
        INSERT INTO users (id, name, surname, role, school_id, school_name, class, class_group)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      `, [childId, 'Тест', 'Ребенок', 'child', school.id, school.name, '1А', '1А']);
        }

        await client.query('COMMIT');
        // Показываем созданного/обновленного пользователя
        const result = await client.query(`
      SELECT id, name, surname, role, school_id, school_name, class, class_group
      FROM users 
      WHERE id = $1
    `, [childId]);
        const user = result.rows[0];
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('❌ Error seeding test child:', error);
        throw error;
    } finally {
        client.release();
    }
};

// Запуск seeding если файл выполняется напрямую
if (process.argv[1] && process.argv[1].includes('seed-test-child.ts')) {
    seedTestChild()
        .then(() => {
            process.exit(0);
        })
        .catch((error) => {
            console.error('💥 Seeding failed:', error);
            process.exit(1);
        });
}

export { seedTestChild };
