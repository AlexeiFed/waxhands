/**
 * @file: check-service-structure.ts
 * @description: Детальная проверка структуры таблицы services
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */

import pool from './connection.js';

export const checkServiceStructure = async (): Promise<void> => {
    const client = await pool.connect();

    try {
        const structureResult = await client.query(`
            SELECT column_name, data_type, is_nullable, column_default
            FROM information_schema.columns 
            WHERE table_name = 'services'
            ORDER BY ordinal_position
        `);
        structureResult.rows.forEach(row => {
        });
        const dataResult = await client.query(`
            SELECT id, name, styles, options, created_at
            FROM services
            LIMIT 3
        `);
        dataResult.rows.forEach((row, index) => {
        });

    } finally {
        client.release();
    }
};

// Запуск скрипта
checkServiceStructure().catch(console.error);
