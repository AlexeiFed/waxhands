/**
 * @file: backend/src/database/clean-chat-tables.ts
 * @description: Скрипт для очистки всех таблиц чата в базе данных
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */

import { db } from './connection';

export async function cleanChatTables() {
    try {
        // Проверяем существование таблиц
        const tables = await db.query(`
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_name IN ('chats', 'chat_messages', 'chat_notifications')
            ORDER BY table_name
        `);

        if (tables.rows.length === 0) {
            // Импортируем и создаем таблицы
            const { createChatTables } = await import('./create-chat-tables');
            await createChatTables();
        }
        // Очищаем таблицы в правильном порядке (с учетом foreign keys)
        await db.query('DELETE FROM chat_notifications');
        await db.query('DELETE FROM chat_messages');
        await db.query('DELETE FROM chats');
        // Сбрасываем автоинкрементные счетчики (если есть)
        try {
            await db.query('ALTER SEQUENCE IF EXISTS chats_id_seq RESTART WITH 1');
            await db.query('ALTER SEQUENCE IF EXISTS chat_messages_id_seq RESTART WITH 1');
            await db.query('ALTER SEQUENCE IF EXISTS chat_notifications_id_seq RESTART WITH 1');
        } catch (error) {
            // UUID не используют автоинкремент, поэтому ошибка ожидаема
            console.log('ℹ️ Счетчики не найдены (используются UUID)');
        }

        // Проверяем, что таблицы пусты
        const chatCount = await db.query('SELECT COUNT(*) as count FROM chats');
        const messageCount = await db.query('SELECT COUNT(*) as count FROM chat_messages');
        const notificationCount = await db.query('SELECT COUNT(*) as count FROM chat_notifications');
    } catch (error) {
        console.error('❌ Ошибка очистки таблиц чата:', error);
        throw error;
    }
}

// Если файл запускается напрямую
if (import.meta.url === `file://${process.argv[1]}`) {
    cleanChatTables()
        .then(() => {
            process.exit(0);
        })
        .catch((error) => {
            console.error('💥 Ошибка очистки:', error);
            process.exit(1);
        });
}
