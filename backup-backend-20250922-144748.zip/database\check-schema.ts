/**
 * @file: check-schema.ts
 * @description: Скрипт для проверки структуры таблицы master_class_events
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */

import pool from './connection.js';

const checkSchema = async (): Promise<void> => {
    const client = await pool.connect();

    try {
        // Проверяем все колонки в таблице master_class_events
        const result = await client.query(`
            SELECT column_name, data_type, is_nullable, column_default
            FROM information_schema.columns 
            WHERE table_name = 'master_class_events'
            ORDER BY ordinal_position
        `);
        result.rows.forEach(row => {
        });

        // Проверяем, есть ли поле city
        const cityField = result.rows.find(row => row.column_name === 'city');
        if (cityField) {
        } else {
        }

        // Проверяем образцы данных
        const dataResult = await client.query(`
            SELECT id, date, time, school_name, class_group, city
            FROM master_class_events 
            LIMIT 3
        `);

        if (dataResult.rows.length > 0) {
            dataResult.rows.forEach((row, index) => {
            });
        } else {
        }

    } catch (error) {
        console.error('❌ Ошибка при проверке схемы:', error);
        throw error;
    } finally {
        client.release();
    }
};

// Запуск проверки, если файл выполняется напрямую
checkSchema()
    .then(() => {
        process.exit(0);
    })
    .catch((error) => {
        console.error('❌ Ошибка проверки схемы:', error);
        process.exit(1);
    });

export { checkSchema };
