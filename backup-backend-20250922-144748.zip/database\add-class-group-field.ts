/**
 * @file: add-class-group-field.ts
 * @description: Миграция для добавления поля class_group в таблицу users
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */

import pool from './connection.js';

const addClassGroupField = async () => {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        // Проверяем, существует ли уже поле class_group
        const columnExists = await client.query(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'users' AND column_name = 'class_group'
    `);

        if (columnExists.rows.length === 0) {
            // Добавляем поле class_group
            await client.query(`
        ALTER TABLE users 
        ADD COLUMN class_group VARCHAR(50)
      `);
            // Копируем данные из поля class в class_group для существующих записей
            await client.query(`
        UPDATE users 
        SET class_group = class 
        WHERE class_group IS NULL AND class IS NOT NULL
      `);
        } else {
        }

        await client.query('COMMIT');
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('❌ Error adding class_group field:', error);
        throw error;
    } finally {
        client.release();
    }
};

// Запуск миграции если файл выполняется напрямую
if (process.argv[1] && process.argv[1].includes('add-class-group-field.ts')) {
    addClassGroupField()
        .then(() => {
            process.exit(0);
        })
        .catch((error) => {
            console.error('💥 Migration failed:', error);
            process.exit(1);
        });
}

export { addClassGroupField };
