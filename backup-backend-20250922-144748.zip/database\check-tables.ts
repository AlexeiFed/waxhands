/**
 * @file: check-tables.ts
 * @description: Проверка существующих таблиц в БД
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */

import pool from './connection.js';

export const checkTables = async (): Promise<void> => {
    const client = await pool.connect();

    try {
        const result = await client.query(`
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public'
            ORDER BY table_name
        `);
        result.rows.forEach(row => {
        });

        // Проверяем структуру таблицы services
        try {
            const servicesResult = await client.query(`
                SELECT column_name, data_type, is_nullable
                FROM information_schema.columns 
                WHERE table_name = 'services'
                ORDER BY ordinal_position
            `);
            servicesResult.rows.forEach(row => {
            });
        } catch (error) {
        }

    } finally {
        client.release();
    }
};

// Запуск скрипта
checkTables().catch(console.error);
