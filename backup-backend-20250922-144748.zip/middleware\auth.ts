import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { JwtPayload } from '../types/index.js';
import pool from '../database/connection.js';

// Расширение интерфейса Request для включения пользователя
declare module 'express' {
    interface Request {
        user?: JwtPayload;
    }
}

export const authenticateToken = (req: Request, res: Response, next: NextFunction): void => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {

        res.status(401).json({
            success: false,
            error: 'Access token required'
        });
        return;
    }

    try {
        const jwtSecret = process.env.JWT_SECRET || 'fallback_secret';
        const decoded = jwt.verify(token, jwtSecret) as JwtPayload;

        // Добавляем информацию о пользователе в request
        req.user = decoded;

        next();
    } catch (error) {

        res.status(403).json({
            success: false,
            error: 'Invalid or expired token'
        });
    }
};

export const authorizeAdmin = (req: Request, res: Response, next: NextFunction): void => {
    const user = req.user;

    if (user?.role !== 'admin') {
        res.status(403).json({
            success: false,
            error: 'Admin access required'
        });
        return;
    }

    next();
};

export const authorizeParentOrAdmin = (req: Request, res: Response, next: NextFunction): void => {
    const user = req.user;
    const { parentId } = req.params;

    // Админы имеют доступ ко всему
    if (user?.role === 'admin') {
        next();
        return;
    }

    // Родители имеют доступ только к своим детям
    if (user?.role === 'parent' && user.userId === parentId) {
        next();
        return;
    }

    res.status(403).json({
        success: false,
        error: 'Access denied'
    });
};

export const authorizeRoles = (...roles: string[]) => {
    return (req: Request, res: Response, next: NextFunction) => {
        if (!req.user) {
            res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
            return;
        }

        if (!roles.includes(req.user.role)) {
            res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
            return;
        }

        next();
    };
};

export const authorizeChild = authorizeRoles('child');
export const authorizeExecutor = authorizeRoles('executor');

// Алиас для requireRole (используется в некоторых маршрутах)
export const requireRole = (...roles: string[]) => {
    return (req: Request, res: Response, next: NextFunction) => {
        // Flatten roles array if it contains nested arrays
        const flatRoles = roles.flat();

        if (!req.user) {

            res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
            return;
        }

        // Проверяем, что роль существует и является строкой
        if (!req.user.role || typeof req.user.role !== 'string') {

            res.status(403).json({
                success: false,
                error: 'Invalid user role'
            });
            return;
        }

        if (!flatRoles.includes(req.user.role)) {

            res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
            return;
        }

        next();
    };
};

// Middleware для проверки владения ресурсом (для родителей и детей)
export const authorizeResourceOwner = (resourceUserIdField: string = 'user_id') => {
    return (req: Request, res: Response, next: NextFunction) => {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
        }

        // Администраторы имеют доступ ко всем ресурсам
        if (req.user.role === 'admin') {
            return next();
        }

        // Проверяем, принадлежит ли ресурс пользователю
        const resourceUserId = req.params[resourceUserIdField] || req.body[resourceUserIdField];

        if (resourceUserId && resourceUserId !== req.user.userId) {
            return res.status(403).json({
                success: false,
                error: 'Access denied to this resource'
            });
        }

        next();
    };
};

// Middleware для проверки прав родителя на мастер-класс
export const authorizeMasterClassParent = async (req: Request, res: Response, next: NextFunction) => {
    try {
        console.log('🔍 authorizeMasterClassParent middleware START:', {
            userId: req.user?.userId,
            role: req.user?.role,
            masterClassId: req.params.id,
            method: req.method,
            url: req.url,
            body: req.body
        });

        if (!req.user) {
            console.log('❌ No user in request');
            return res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
        }

        // Администраторы имеют доступ ко всем мастер-классам
        if (req.user.role === 'admin') {
            console.log('✅ Admin access granted');
            return next();
        }

        // Для родителей проверяем, есть ли их дети в участниках мастер-класса
        if (req.user.role === 'parent') {
            const { id: masterClassId } = req.params;

            console.log('🔍 Checking parent access for master class:', masterClassId);

            // Получаем информацию о мастер-классе
            const masterClassResult = await pool.query(
                'SELECT participants FROM master_class_events WHERE id = $1',
                [masterClassId]
            );

            if (masterClassResult.rows.length === 0) {
                console.log('❌ Master class not found');
                return res.status(404).json({
                    success: false,
                    error: 'Master class not found'
                });
            }

            const participants = masterClassResult.rows[0].participants || [];
            console.log('🔍 Participants in master class:', {
                count: participants.length,
                participants: participants.map((p: any) => ({
                    id: p.id,
                    parentId: p.parentId,
                    childId: p.childId,
                    childName: p.childName
                }))
            });
            console.log('🔍 Looking for parentId:', req.user.userId);

            // Проверяем, есть ли среди участников дети этого родителя
            const hasAccess = participants.some((participant: any) => {
                console.log('🔍 Checking participant:', {
                    participantId: participant.id,
                    parentId: participant.parentId,
                    childId: participant.childId,
                    currentUserId: req.user?.userId,
                    matches: participant.parentId === req.user?.userId
                });
                return participant.parentId === req.user?.userId;
            });

            console.log('🔍 Has access:', hasAccess);

            if (!hasAccess) {
                console.log('❌ Access denied - parent not found in participants');
                return res.status(403).json({
                    success: false,
                    error: 'Access denied. You can only modify master classes where your children are participants'
                });
            }

            console.log('✅ Parent access granted');
            return next();
        }

        console.log('❌ Invalid role:', req.user.role);
        return res.status(403).json({
            success: false,
            error: 'Access denied'
        });

    } catch (error) {
        console.error('❌ Error in authorizeMasterClassParent:', error);
        return res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
};

// Middleware для логирования запросов
export const logRequest = (req: Request, res: Response, next: NextFunction) => {
    const start = Date.now();

    res.on('finish', () => {
        const duration = Date.now() - start;

    });

    next();
};

// Middleware для обработки ошибок
export const errorHandler = (err: Error, req: Request, res: Response, next: NextFunction) => {
    console.error('Error:', err);

    if (err.name === 'ValidationError') {
        return res.status(400).json({
            success: false,
            error: 'Validation error',
            details: err.message
        });
    }

    if (err.name === 'UnauthorizedError') {
        return res.status(401).json({
            success: false,
            error: 'Unauthorized'
        });
    }

    return res.status(500).json({
        success: false,
        error: 'Internal server error'
    });
}; 