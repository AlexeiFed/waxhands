/**
 * @file: clean-blob-urls.ts
 * @description: Скрипт для очистки blob URL'ов из стилей и опций услуг
 * @created: 2024-12-19
 */

import pool from './connection.js';

const cleanBlobUrls = async () => {
    const client = await pool.connect();

    try {
        await client.query('BEGIN');

        // Получаем все услуги
        const servicesResult = await client.query('SELECT id, name, styles, options FROM services');

        for (const service of servicesResult.rows) {
            let stylesUpdated = false;
            let optionsUpdated = false;

            // Очищаем стили
            let styles = service.styles || [];
            if (Array.isArray(styles)) {
                styles = styles.map((style: { name: string; avatar: string | null; images?: string[]; videos?: string[] }) => {
                    let styleUpdated = false;

                    // Очищаем blob URLs в аватаре
                    if (style.avatar && style.avatar.startsWith('blob:')) {

                        style.avatar = null;
                        styleUpdated = true;
                    }

                    // Очищаем blob URLs в изображениях
                    if (style.images && Array.isArray(style.images)) {
                        const cleanImages = style.images.filter((img: string) => !img.startsWith('blob:'));
                        if (cleanImages.length !== style.images.length) {

                            style.images = cleanImages;
                            styleUpdated = true;
                        }
                    }

                    // Очищаем blob URLs в видео
                    if (style.videos && Array.isArray(style.videos)) {
                        const cleanVideos = style.videos.filter((vid: string) => !vid.startsWith('blob:'));
                        if (cleanVideos.length !== style.videos.length) {

                            style.videos = cleanVideos;
                            styleUpdated = true;
                        }
                    }

                    if (styleUpdated) stylesUpdated = true;
                    return style;
                });
            }

            // Очищаем опции
            let options = service.options || [];
            if (Array.isArray(options)) {
                options = options.map((option: { name: string; avatar: string | null; images?: string[]; videos?: string[] }) => {
                    let optionUpdated = false;

                    // Очищаем blob URLs в аватаре
                    if (option.avatar && option.avatar.startsWith('blob:')) {

                        option.avatar = null;
                        optionUpdated = true;
                    }

                    // Очищаем blob URLs в изображениях
                    if (option.images && Array.isArray(option.images)) {
                        const cleanImages = option.images.filter((img: string) => !img.startsWith('blob:'));
                        if (cleanImages.length !== option.images.length) {

                            option.images = cleanImages;
                            optionUpdated = true;
                        }
                    }

                    // Очищаем blob URLs в видео
                    if (option.videos && Array.isArray(option.videos)) {
                        const cleanVideos = option.videos.filter((vid: string) => !vid.startsWith('blob:'));
                        if (cleanVideos.length !== option.videos.length) {

                            option.videos = cleanVideos;
                            optionUpdated = true;
                        }
                    }

                    if (optionUpdated) optionsUpdated = true;
                    return option;
                });
            }

            // Обновляем услугу если есть изменения
            if (stylesUpdated || optionsUpdated) {
                await client.query(
                    'UPDATE services SET styles = $1, options = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3',
                    [JSON.stringify(styles), JSON.stringify(options), service.id]
                );

            }
        }

        await client.query('COMMIT');

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('❌ Blob URLs cleanup failed:', error);
        throw error;
    } finally {
        client.release();
    }
};

cleanBlobUrls()
    .then(() => {

        process.exit(0);
    })
    .catch((error) => {
        console.error('Cleanup failed:', error);
        process.exit(1);
    });

export default cleanBlobUrls;