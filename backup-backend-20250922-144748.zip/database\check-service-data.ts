/**
 * @file: check-service-data.ts
 * @description: Проверка данных в таблице services
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */

import pool from './connection.js';

export const checkServiceData = async (): Promise<void> => {
    const client = await pool.connect();
    
    try {
        const result = await client.query(`
            SELECT id, name, options, created_at
            FROM services
            LIMIT 5
        `);
        result.rows.forEach((row, index) => {
        });
        
    } finally {
        client.release();
    }
};

// Запуск скрипта
checkServiceData().catch(console.error);
