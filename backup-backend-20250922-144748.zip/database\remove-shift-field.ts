/**
 * @file: remove-shift-field.ts
 * @description: Миграция для удаления поля shift из таблицы users
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */

import pool from './connection.js';

const removeShiftField = async () => {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        // Проверяем, существует ли поле shift
        const columnExists = await client.query(`
            SELECT column_name 
            FROM information_schema.columns 
            WHERE table_name = 'users' AND column_name = 'shift'
        `);

        if (columnExists.rows.length > 0) {
            // Удаляем поле shift
            await client.query(`
                ALTER TABLE users 
                DROP COLUMN shift
            `);
        } else {
        }

        await client.query('COMMIT');
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('❌ Error removing shift field:', error);
        throw error;
    } finally {
        client.release();
    }
};

// Запуск миграции если файл выполняется напрямую
if (process.argv[1] && process.argv[1].includes('remove-shift-field.ts')) {
    removeShiftField()
        .then(() => {
            process.exit(0);
        })
        .catch((error) => {
            console.error('💥 Migration failed:', error);
            process.exit(1);
        });
}

export { removeShiftField };
