/**
 * @file: robokassaService.ts
 * @description: Сервис для интеграции с Robokassa
 * @dependencies: types/robokassa.ts, crypto, jwt
 * @created: 2025-01-26
 */
import { RobokassaCreateInvoiceResponse, RobokassaResultNotification, RobokassaJWSNotification, RobokassaRefundRequest, RobokassaRefundResponse, RobokassaRefundStatus, CreateRobokassaInvoiceData } from '../types/robokassa.js';
export declare class RobokassaService {
    private config;
    constructor();
    /**
     * Создает JWT токен для Robokassa API
     */
    private createJWTToken;
    /**
     * Создает подпись для строки
     */
    private createSignature;
    /**
     * Кодирует строку в Base64Url
     */
    private base64UrlEncode;
    /**
     * Декодирует Base64Url строку
     */
    private base64UrlDecode;
    /**
     * Создает фискальный чек для Robokassa
     */
    private createReceipt;
    /**
     * Создает счет в Robokassa
     */
    createInvoice(data: CreateRobokassaInvoiceData): Promise<RobokassaCreateInvoiceResponse>;
    /**
     * Проверяет подпись уведомления от Robokassa
     */
    verifyResultSignature(notification: RobokassaResultNotification): boolean;
    /**
     * Проверяет подпись JWS уведомления
     */
    verifyJWSNotification(jwsToken: string): RobokassaJWSNotification | null;
    /**
     * Инициирует возврат средств
     */
    createRefund(refundData: RobokassaRefundRequest): Promise<RobokassaRefundResponse>;
    /**
     * Получает статус возврата
     */
    getRefundStatus(requestId: string): Promise<RobokassaRefundStatus | null>;
    /**
     * Проверяет, доступна ли оплата для пользователя (только для Сафонова)
     */
    isPaymentAvailableForUser(userData: {
        surname?: string;
        phone?: string;
    }): boolean;
}
export declare const robokassaService: RobokassaService;
//# sourceMappingURL=robokassaService.d.ts.map