/**
 * @file: paymentController.ts
 * @description: Универсальный контроллер для работы с платежными системами (Robokassa, FreeKassa и др.)
 * @dependencies: PaymentFactory, IPaymentProvider
 * @created: 2025-10-16
 */
import { Request, Response } from 'express';
import { UserRole } from '../types/index.js';
interface AuthenticatedRequest extends Request {
    user?: {
        userId: string;
        role: UserRole;
        email?: string;
        iat: number;
        exp: number;
    };
}
/**
 * Создает ссылку на оплату (универсальный метод для всех провайдеров)
 */
export declare const createPaymentLink: (req: AuthenticatedRequest, res: Response) => Promise<void>;
/**
 * Обрабатывает уведомления от платежных систем (универсальный webhook)
 */
export declare const handlePaymentWebhook: (req: Request, res: Response) => Promise<void>;
/**
 * Обрабатывает возврат пользователя после успешной оплаты
 */
export declare const handleSuccessRedirect: (req: Request, res: Response) => Promise<void>;
/**
 * Обрабатывает возврат пользователя при отказе от оплаты
 */
export declare const handleFailRedirect: (req: Request, res: Response) => Promise<void>;
/**
 * Проверяет возможность возврата для счета
 */
export declare const checkRefundAvailability: (req: AuthenticatedRequest, res: Response) => Promise<void>;
/**
 * Получает информацию о текущем платежном провайдере
 */
export declare const getProviderInfo: (req: Request, res: Response) => Promise<void>;
export {};
//# sourceMappingURL=paymentController.d.ts.map