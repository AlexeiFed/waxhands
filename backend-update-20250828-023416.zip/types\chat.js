/**
 * @file: backend/src/types/chat.ts
 * @description: Типы для системы чата между пользователями и администраторами
 * @dependencies: index.ts
 * @created: 2024-12-19
 */
export {};
//# sourceMappingURL=chat.js.map