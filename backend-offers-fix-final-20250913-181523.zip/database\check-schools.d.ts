/**
 * @file: check-schools.ts
 * @description: Скрипт для проверки таблицы schools и данных в ней
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */
declare const checkSchools: () => Promise<void>;
export { checkSchools };
//# sourceMappingURL=check-schools.d.ts.map