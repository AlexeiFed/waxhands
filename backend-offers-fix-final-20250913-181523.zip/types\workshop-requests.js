/**
 * @file: backend/src/types/workshop-requests.ts
 * @description: Типы для заявок на проведение мастер-классов
 * @dependencies: index.ts
 * @created: 2024-12-19
 */
export {};
//# sourceMappingURL=workshop-requests.js.map