/**
 * @file: upload.ts
 * @description: Маршруты для загрузки файлов
 * @dependencies: Router, authenticateToken, upload middleware
 * @created: 2024-12-19
 */
declare const router: import("@types/express-serve-static-core/index.js").Router;
export default router;
//# sourceMappingURL=upload.d.ts.map