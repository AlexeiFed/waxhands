/**
 * @file: seed-master-class-events.ts
 * @description: Скрипт для добавления тестовых данных мастер-классов
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */
declare const seedMasterClassEvents: () => Promise<void>;
export { seedMasterClassEvents };
//# sourceMappingURL=seed-master-class-events.d.ts.map