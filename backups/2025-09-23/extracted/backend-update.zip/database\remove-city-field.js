/**
 * @file: remove-city-field.ts
 * @description: Миграция для удаления поля city из таблицы master_class_events
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */
import pool from './connection.js';
export const removeCityField = async () => {
    const client = await pool.connect();
    try {
        // Проверяем, существует ли поле city
        const checkResult = await client.query(`
            SELECT column_name 
            FROM information_schema.columns 
            WHERE table_name = 'master_class_events' 
            AND column_name = 'city'
        `);
        if (checkResult.rows.length === 0) {
            return;
        }
        // Удаляем поле city
        await client.query('ALTER TABLE master_class_events DROP COLUMN city');
    }
    catch (error) {
        console.error('❌ Ошибка при удалении поля city:', error);
        throw error;
    }
    finally {
        client.release();
    }
};
// Запуск миграции, если файл выполняется напрямую
removeCityField()
    .then(() => {
    process.exit(0);
})
    .catch((error) => {
    console.error('❌ Ошибка миграции remove-city-field:', error);
    process.exit(1);
});
//# sourceMappingURL=remove-city-field.js.map