/**
 * @file: debug-query.ts
 * @description: Отладочный скрипт для проверки SQL запросов
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */
declare const debugQuery: () => Promise<void>;
export { debugQuery };
//# sourceMappingURL=debug-query.d.ts.map