/**
 * @file: offers.ts
 * @description: API маршруты для управления офертами
 * @dependencies: express, Offer, CreateOfferRequest, UpdateOfferRequest
 * @created: 2024-12-19
 */
declare const router: import("@types/express-serve-static-core/index.js").Router;
export default router;
//# sourceMappingURL=offers.d.ts.map