/**
 * @file: robokassaService.ts
 * @description: Сервис для интеграции с Robokassa
 * @dependencies: types/robokassa.ts, crypto, jwt
 * @created: 2025-01-26
 */
import crypto from 'crypto';
import jwt from 'jsonwebtoken';
export class RobokassaService {
    config;
    constructor() {
        this.config = {
            merchantLogin: process.env.ROBOKASSA_MERCHANT_LOGIN || 'waxhands.ru',
            password1: process.env.ROBOKASSA_PASSWORD_1 || '',
            password2: process.env.ROBOKASSA_PASSWORD_2 || '',
            password3: process.env.ROBOKASSA_PASSWORD_3 || '',
            testMode: process.env.ROBOKASSA_TEST_MODE === 'true',
            successUrl: process.env.ROBOKASSA_SUCCESS_URL || 'https://waxhands.ru/payment/robokassa/success',
            failUrl: process.env.ROBOKASSA_FAIL_URL || 'https://waxhands.ru/payment/robokassa/fail',
            resultUrl: process.env.ROBOKASSA_RESULT_URL || 'https://waxhands.ru/api/robokassa/payment-webhook/robokassa',
            algorithm: process.env.ROBOKASSA_ALGORITHM || 'MD5'
        };
    }
    /**
     * Создает JWT токен для Robokassa API
     */
    createJWTToken(payload) {
        const header = {
            typ: 'JWT',
            alg: this.config.algorithm
        };
        // Кодируем header и payload в Base64Url
        const encodedHeader = this.base64UrlEncode(JSON.stringify(header));
        const encodedPayload = this.base64UrlEncode(JSON.stringify(payload));
        // Создаем строку для подписи
        const signatureString = `${encodedHeader}.${encodedPayload}`;
        // Создаем подпись
        const secretKey = `${this.config.merchantLogin}:${this.config.password1}`;
        const signature = this.createSignature(signatureString, secretKey);
        return `${signatureString}.${signature}`;
    }
    /**
     * Создает подпись для строки (MD5 для тестового режима, HMAC для JWT)
     */
    createSignature(data, secret, useMD5 = false) {
        if (useMD5) {
            // Для тестового режима используем обычный MD5
            return crypto.createHash('md5').update(data).digest('hex');
        }
        // Для JWT используем HMAC
        switch (this.config.algorithm) {
            case 'MD5':
                return crypto.createHmac('md5', secret).update(data).digest('base64');
            case 'SHA1':
                return crypto.createHmac('sha1', secret).update(data).digest('base64');
            case 'SHA256':
                return crypto.createHmac('sha256', secret).update(data).digest('base64');
            case 'SHA384':
                return crypto.createHmac('sha384', secret).update(data).digest('base64');
            case 'SHA512':
                return crypto.createHmac('sha512', secret).update(data).digest('base64');
            case 'RIPEMD160':
                return crypto.createHmac('ripemd160', secret).update(data).digest('base64');
            default:
                return crypto.createHmac('md5', secret).update(data).digest('base64');
        }
    }
    /**
     * Кодирует строку в Base64Url
     */
    base64UrlEncode(str) {
        return Buffer.from(str)
            .toString('base64')
            .replace(/\+/g, '-')
            .replace(/\//g, '_')
            .replace(/=/g, '');
    }
    /**
     * Декодирует Base64Url строку
     */
    base64UrlDecode(str) {
        // Добавляем padding если нужно
        const padded = str + '='.repeat((4 - str.length % 4) % 4);
        return Buffer.from(padded.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString();
    }
    /**
     * Создает фискальный чек для Robokassa
     */
    createReceipt(data) {
        const items = [];
        // ИСПРАВЛЕНО: Создаем одну позицию с общей суммой согласно документации
        // Сумма всех позиций в чеке должна быть равна сумме операции
        items.push({
            name: `Мастер-класс "${data.masterClassName}"`,
            quantity: 1,
            sum: data.amount, // Используем общую сумму
            payment_method: "full_prepayment",
            payment_object: "service",
            tax: "vat20"
        });
        return JSON.stringify({
            sno: 'osn', // Общая система налогообложения
            items: items
        });
    }
    /**
     * Создает URL-кодированную строку для Receipt
     */
    createReceiptUrlEncoded(data) {
        const receipt = this.createReceipt(data);
        return encodeURIComponent(receipt);
    }
    /**
     * Создает счет в Robokassa
     */
    async createInvoice(data) {
        try {
            console.log('🔄 Создаем счет в Robokassa:', data);
            // Формируем краткое описание (максимум 50 символов для Robokassa)
            const description = `Мастер-класс "${data.masterClassName}"`;
            // Создаем уникальный ID счета
            const invId = parseInt(data.invoiceId.replace(/-/g, '').substring(0, 10), 16);
            if (this.config.testMode) {
                // Тестовый режим - создаем ссылку на тестовую страницу Robokassa
                console.log('🧪 Создаем тестовую ссылку на оплату');
                // Создаем фискальный чек
                const receipt = this.createReceiptUrlEncoded(data);
                console.log('📄 Создан фискальный чек:', receipt);
                // Создаем подпись для тестового режима (без фискализации для тестов)
                const signatureString = `${this.config.merchantLogin}:${data.amount}:${invId}:${this.config.password1}`;
                const signature = this.createSignature(signatureString, this.config.password1, true); // Используем MD5
                // Формируем URL для тестовой оплаты (без фискализации для тестов)
                const testUrl = `https://auth.robokassa.ru/Merchant/PaymentForm/FormMS.if?` +
                    `MerchantLogin=${this.config.merchantLogin}&` +
                    `OutSum=${data.amount}&` +
                    `InvoiceID=${invId}&` +
                    `Description=${encodeURIComponent(description)}&` +
                    `SignatureValue=${signature}&` +
                    `IsTest=1`;
                console.log('✅ Тестовая ссылка создана:', testUrl);
                return {
                    success: true,
                    invoiceUrl: testUrl,
                    invoiceId: invId.toString()
                };
            }
            else {
                // Продакшн режим - используем обычный интерфейс оплаты С ПРАВИЛЬНОЙ фискализацией
                console.log('🏪 Создаем продакшн ссылку на оплату С фискализацией');
                // Создаем фискальный чек
                const receipt = this.createReceiptUrlEncoded(data);
                console.log('📄 Создан фискальный чек:', receipt);
                // ИСПРАВЛЕНО: Правильная подпись с фискализацией согласно документации
                // База: MerchantLogin:OutSum:InvId:Receipt:Пароль#1
                const signatureString = `${this.config.merchantLogin}:${data.amount}:${invId}:${receipt}:${this.config.password1}`;
                const signature = this.createSignature(signatureString, this.config.password1, true); // Используем простой MD5 для Robokassa
                console.log('🔍 Подпись рассчитана С фискализацией для:', signatureString);
                // Формируем URL для продакшн оплаты С фискализацией
                const productionUrl = `https://auth.robokassa.ru/Merchant/Index.aspx?` +
                    `MerchantLogin=${this.config.merchantLogin}&` +
                    `OutSum=${data.amount}&` +
                    `InvoiceID=${invId}&` +
                    `Description=${encodeURIComponent(description)}&` +
                    `Receipt=${receipt}&` +
                    `SignatureValue=${signature}&` +
                    `Culture=ru&` +
                    `Encoding=utf-8`;
                console.log('✅ Продакшн ссылка создана С фискализацией:', productionUrl);
                return {
                    success: true,
                    invoiceUrl: productionUrl,
                    invoiceId: invId.toString()
                };
            }
        }
        catch (error) {
            console.error('❌ Ошибка при создании счета в Robokassa:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Неизвестная ошибка'
            };
        }
    }
    /**
     * Проверяет подпись уведомления от Robokassa
     */
    verifyResultSignature(notification) {
        try {
            const { OutSum, InvId, SignatureValue, ...shpParams } = notification;
            // Сортируем Shp параметры по алфавиту
            const sortedShpParams = Object.keys(shpParams)
                .filter(key => key.startsWith('Shp_'))
                .sort()
                .map(key => `${key}=${shpParams[key]}`);
            // Формируем строку для проверки подписи
            const signatureString = sortedShpParams.length > 0
                ? `${OutSum}:${InvId}:${this.config.password2}:${sortedShpParams.join(':')}`
                : `${OutSum}:${InvId}:${this.config.password2}`;
            // Создаем подпись
            const expectedSignature = this.createSignature(signatureString, this.config.password2).toUpperCase();
            console.log('🔍 Проверка подписи Robokassa:', {
                signatureString,
                received: SignatureValue,
                expected: expectedSignature,
                match: expectedSignature === SignatureValue.toUpperCase()
            });
            return expectedSignature === SignatureValue.toUpperCase();
        }
        catch (error) {
            console.error('❌ Ошибка при проверке подписи:', error);
            return false;
        }
    }
    /**
     * Проверяет подпись JWS уведомления
     */
    verifyJWSNotification(jwsToken) {
        try {
            const [headerB64, payloadB64, signatureB64] = jwsToken.split('.');
            if (!headerB64 || !payloadB64 || !signatureB64) {
                throw new Error('Invalid JWS format');
            }
            // Декодируем header и payload
            const header = JSON.parse(this.base64UrlDecode(headerB64));
            const payload = JSON.parse(this.base64UrlDecode(payloadB64));
            // Проверяем подпись
            const signatureString = `${headerB64}.${payloadB64}`;
            const expectedSignature = this.createSignature(signatureString, this.config.password2);
            if (expectedSignature !== signatureB64) {
                console.error('❌ Неверная подпись JWS уведомления');
                return null;
            }
            return {
                header,
                data: payload
            };
        }
        catch (error) {
            console.error('❌ Ошибка при проверке JWS уведомления:', error);
            return null;
        }
    }
    /**
     * Инициирует возврат средств
     */
    async createRefund(refundData) {
        try {
            console.log('🔄 Создаем возврат в Robokassa:', refundData);
            const payload = {
                OpKey: refundData.OpKey,
                RefundSum: refundData.RefundSum,
                InvoiceItems: refundData.InvoiceItems
            };
            // Создаем JWT токен для возврата
            const jwtToken = jwt.sign(payload, this.config.password3, { algorithm: 'HS256' });
            const response = await fetch('https://services.robokassa.ru/RefundService/Refund/Create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ token: jwtToken })
            });
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const result = await response.json();
            console.log('✅ Результат создания возврата:', result);
            return {
                success: result.success,
                message: result.message,
                requestId: result.requestId
            };
        }
        catch (error) {
            console.error('❌ Ошибка при создании возврата:', error);
            return {
                success: false,
                message: error instanceof Error ? error.message : 'Неизвестная ошибка'
            };
        }
    }
    /**
     * Получает статус возврата
     */
    async getRefundStatus(requestId) {
        try {
            console.log('🔄 Получаем статус возврата:', requestId);
            const response = await fetch(`https://services.robokassa.ru/RefundService/Refund/GetState?id=${requestId}`);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const result = await response.json();
            if (result.message) {
                console.error('❌ Ошибка получения статуса возврата:', result.message);
                return null;
            }
            return {
                requestId: result.requestId,
                amount: result.amount,
                label: result.label
            };
        }
        catch (error) {
            console.error('❌ Ошибка при получении статуса возврата:', error);
            return null;
        }
    }
    /**
     * Проверяет, доступна ли оплата для пользователя (только для Сафонова)
     */
    isPaymentAvailableForUser(userData) {
        // Проверяем по фамилии и телефону для Сафонова
        const allowedUser = {
            surname: 'Сафонов',
            phone: '+79241002233'
        };
        return userData.surname === allowedUser.surname && userData.phone === allowedUser.phone;
    }
}
export const robokassaService = new RobokassaService();
//# sourceMappingURL=robokassaService.js.map