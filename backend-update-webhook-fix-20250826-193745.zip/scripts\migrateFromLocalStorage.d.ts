declare const migrateData: () => Promise<void>;
declare const runMigration: () => Promise<void>;
export { migrateData, runMigration };
//# sourceMappingURL=migrateFromLocalStorage.d.ts.map