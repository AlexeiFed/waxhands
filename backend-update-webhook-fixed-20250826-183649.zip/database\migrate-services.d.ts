declare const migrateServicesTable: () => Promise<void>;
export default migrateServicesTable;
//# sourceMappingURL=migrate-services.d.ts.map