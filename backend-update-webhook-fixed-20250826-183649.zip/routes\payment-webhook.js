/**
 * @file: payment-webhook.ts
 * @description: Роутер для обработки webhook'ов платежных систем
 * @dependencies: express, payment services, database
 * @created: 2024-12-19
 */
import { Router } from 'express';
import pool from '../database/connection.js';
const router = Router();
// Функция для валидации подписи от ЮMoney
const validateYuMoneySignature = (req) => {
    // TODO: Реализовать валидацию подписи когда ЮMoney предоставит документацию
    // Пока что принимаем все webhook'и для тестирования
    console.log('🔐 Валидация подписи ЮMoney (пока отключена для тестирования)');
    return true;
};
// Функция для обновления статуса счета и полей платежа
const updateInvoicePaymentStatus = async (invoiceId, paymentId, status, paymentMethod, paymentDate) => {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        console.log(`🔄 Обновляем счет ${invoiceId}: статус=${status}, payment_id=${paymentId}`);
        // Обновляем счет
        const updateResult = await client.query(`UPDATE invoices 
             SET status = $1, 
                 payment_id = $2, 
                 payment_method = $3, 
                 payment_date = $4, 
                 updated_at = CURRENT_TIMESTAMP 
             WHERE id = $5 
             RETURNING *`, [status, paymentId, paymentMethod, paymentDate, invoiceId]);
        if (updateResult.rows.length === 0) {
            console.error(`❌ Счет ${invoiceId} не найден`);
            await client.query('ROLLBACK');
            return false;
        }
        const invoice = updateResult.rows[0];
        console.log(`✅ Счет обновлен:`, {
            id: invoice.id,
            status: invoice.status,
            payment_id: invoice.payment_id,
            payment_method: invoice.payment_method,
            payment_date: invoice.payment_date
        });
        // Синхронизируем статус оплаты с участниками мастер-класса
        if (invoice.master_class_id && invoice.participant_id) {
            try {
                console.log(`🔄 Синхронизируем статус оплаты для участника ${invoice.participant_id}`);
                // Получаем текущий мастер-класс
                const masterClassResult = await client.query('SELECT participants, statistics FROM master_class_events WHERE id = $1', [invoice.master_class_id]);
                if (masterClassResult.rows.length > 0) {
                    const masterClass = masterClassResult.rows[0];
                    let participants = masterClass.participants || [];
                    // Обновляем статус оплаты для участника
                    participants = participants.map((p) => {
                        if (p.id === invoice.participant_id) {
                            const oldStatus = p.isPaid;
                            p.isPaid = status === 'paid';
                            console.log(`🔄 Участник ${p.childName}: статус оплаты ${oldStatus} → ${p.isPaid}`);
                        }
                        return p;
                    });
                    // Пересчитываем статистику
                    let totalPaidAmount = 0;
                    let totalUnpaidAmount = 0;
                    participants.forEach((p) => {
                        if (p.isPaid) {
                            totalPaidAmount += p.totalAmount || 0;
                        }
                        else {
                            totalUnpaidAmount += p.totalAmount || 0;
                        }
                    });
                    // Обновляем мастер-класс
                    await client.query(`UPDATE master_class_events 
                         SET participants = $1::jsonb, 
                             statistics = jsonb_set(
                                 jsonb_set(
                                     COALESCE(statistics, '{}'::jsonb),
                                     '{paidAmount}', to_jsonb($2::numeric)
                                 ),
                                 '{unpaidAmount}', to_jsonb($3::numeric)
                             ),
                             updated_at = CURRENT_TIMESTAMP
                         WHERE id = $4`, [JSON.stringify(participants), totalPaidAmount, totalUnpaidAmount, invoice.master_class_id]);
                    console.log(`✅ Статус оплаты синхронизирован для мастер-класса ${invoice.master_class_id}`);
                }
            }
            catch (syncError) {
                console.error(`❌ Ошибка синхронизации статуса оплаты:`, syncError);
                // Не прерываем выполнение, только логируем ошибку
            }
        }
        await client.query('COMMIT');
        return true;
    }
    catch (error) {
        console.error(`❌ Ошибка обновления счета ${invoiceId}:`, error);
        await client.query('ROLLBACK');
        return false;
    }
    finally {
        client.release();
    }
};
// Webhook для ЮMoney
router.post('/yumoney', async (req, res) => {
    try {
        console.log('🔔 Webhook от ЮMoney получен:', JSON.stringify(req.body, null, 2));
        // Валидируем подпись
        if (!validateYuMoneySignature(req)) {
            console.error('❌ Неверная подпись от ЮMoney');
            res.status(401).json({
                success: false,
                error: 'Unauthorized'
            });
            return;
        }
        const webhookData = req.body;
        // Обрабатываем разные типы уведомлений
        if (webhookData.notification_type === 'p2p-incoming') {
            // P2P перевод (прямой перевод на кошелек)
            console.log(`💰 Получен P2P перевод: ${webhookData.amount} ${webhookData.currency}`);
            console.log(`👤 От: ${webhookData.sender}, Дата: ${webhookData.datetime}`);
            // TODO: Обработать P2P перевод (возможно, по sender или label найти счет)
            res.json({
                success: true,
                message: 'P2P transfer received',
                amount: webhookData.amount,
                sender: webhookData.sender
            });
            return;
        }
        if (webhookData.notification_type === 'card-incoming') {
            // Платеж картой
            console.log(`💳 Получен платеж картой: ${webhookData.amount} ${webhookData.currency}`);
            // TODO: Обработать платеж картой
            res.json({
                success: true,
                message: 'Card payment received',
                amount: webhookData.amount
            });
            return;
        }
        // Проверяем тип события для платежей через формы
        if (webhookData.event === 'payment.succeeded') {
            const payment = webhookData.object;
            if (!payment) {
                console.error('❌ Объект платежа не найден');
                res.status(400).json({
                    success: false,
                    error: 'Missing payment object'
                });
                return;
            }
            const metadata = payment.metadata || {};
            const invoiceId = metadata.invoice_id;
            if (!invoiceId) {
                console.error('❌ invoice_id не найден в metadata платежа');
                res.status(400).json({
                    success: false,
                    error: 'Missing invoice_id in payment metadata'
                });
                return;
            }
            console.log(`💰 Обрабатываем успешную оплату для счета ${invoiceId}`);
            console.log(`🔍 Данные платежа:`, {
                payment_id: payment.id,
                amount: payment.amount.value,
                currency: payment.amount.currency,
                method: payment.payment_method.type,
                created_at: payment.created_at,
                captured_at: payment.captured_at
            });
            // Обновляем статус счета
            const success = await updateInvoicePaymentStatus(invoiceId, payment.id, 'paid', payment.payment_method.type, payment.captured_at || payment.created_at);
            if (success) {
                console.log(`✅ Счет ${invoiceId} успешно обновлен на статус 'paid'`);
                // TODO: Отправить WebSocket уведомление о успешной оплате
                res.json({
                    success: true,
                    message: 'Payment processed successfully',
                    invoice_id: invoiceId,
                    payment_id: payment.id
                });
            }
            else {
                console.error(`❌ Не удалось обновить счет ${invoiceId}`);
                res.status(500).json({
                    success: false,
                    error: 'Failed to update invoice'
                });
            }
            return;
        }
        // Если это тестовое уведомление
        if (webhookData.test_notification === 'true') {
            console.log(`🧪 Тестовое уведомление от ЮMoney: ${webhookData.notification_type}`);
            res.json({
                success: true,
                message: 'Test notification received',
                notification_type: webhookData.notification_type,
                amount: webhookData.amount
            });
            return;
        }
        // Неизвестный тип уведомления
        console.log(`ℹ️ Неизвестный тип уведомления: ${webhookData.notification_type}`);
        res.status(200).json({
            success: true,
            message: 'Unknown notification type',
            notification_type: webhookData.notification_type
        });
    }
    catch (error) {
        console.error('❌ Ошибка обработки webhook\'а от ЮMoney:', error);
        res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
});
// Webhook для других платежных систем
router.post('/generic', async (req, res) => {
    try {
        console.log('🔔 Generic webhook получен:', JSON.stringify(req.body, null, 2));
        res.status(200).json({
            success: true,
            message: 'Generic webhook received'
        });
    }
    catch (error) {
        console.error('❌ Ошибка generic webhook:', error);
        res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
});
export default router;
//# sourceMappingURL=payment-webhook.js.map