/**
 * @file: FreekassaProvider.ts
 * @description: Провайдер для интеграции с FreeKassa
 * @dependencies: IPaymentProvider, crypto
 * @created: 2025-10-16
 */
import crypto from 'crypto';
export class FreekassaProvider {
    providerName = 'FreeKassa';
    config;
    constructor() {
        this.config = {
            merchantId: process.env.FREEKASSA_MERCHANT_ID || '',
            apiKey: process.env.FREEKASSA_API_KEY || '',
            secretWord1: process.env.FREEKASSA_SECRET_WORD_1 || '',
            secretWord2: process.env.FREEKASSA_SECRET_WORD_2 || '',
            successUrl: process.env.FREEKASSA_SUCCESS_URL || 'https://waxhands.ru/payment/success',
            failUrl: process.env.FREEKASSA_FAIL_URL || 'https://waxhands.ru/payment/fail',
            webhookUrl: process.env.FREEKASSA_WEBHOOK_URL || 'https://waxhands.ru/api/payment/webhook'
        };
        console.log('🔧 FreekassaProvider конфигурация:', {
            merchantId: this.config.merchantId,
            successUrl: this.config.successUrl,
            failUrl: this.config.failUrl,
            webhookUrl: this.config.webhookUrl,
            secretWord1Length: this.config.secretWord1?.length || 0,
            secretWord2Length: this.config.secretWord2?.length || 0
        });
    }
    /**
     * Создает подпись для платежа (платежная форма)
     * Формат согласно документации: MD5(merchantId:amount:secretWord1:currency:orderId)
     */
    createPaymentSignature(merchantId, amount, secret, currency, orderId) {
        const signatureString = `${merchantId}:${amount.toFixed(2)}:${secret}:${currency}:${orderId}`;
        const signature = crypto.createHash('md5').update(signatureString).digest('hex');
        console.log('🔐 FreeKassa - подпись платежа:', {
            signatureString,
            signature
        });
        return signature;
    }
    /**
     * Создает подпись для API запросов
     * Формат согласно документации: HMAC-SHA256(sortedValues, apiKey)
     */
    createApiSignature(data) {
        // Сортируем параметры по ключам в алфавитном порядке
        const sortedKeys = Object.keys(data).sort();
        // Объединяем значения с разделителем |
        const values = sortedKeys.map(key => String(data[key]));
        const signatureString = values.join('|');
        // Хешируем HMAC-SHA256 с API ключом
        const signature = crypto
            .createHmac('sha256', this.config.apiKey)
            .update(signatureString)
            .digest('hex');
        console.log('🔐 FreeKassa API - подпись:', {
            sortedKeys,
            values,
            signatureString,
            signature
        });
        return signature;
    }
    /**
     * Создает подпись для проверки уведомления (webhook)
     * Формат согласно документации: MD5(MERCHANT_ID:AMOUNT:secretWord2:MERCHANT_ORDER_ID)
     */
    verifyWebhookSignature(merchantId, amount, secret, orderId, signature) {
        const signatureString = `${merchantId}:${amount}:${secret}:${orderId}`;
        const expectedSignature = crypto.createHash('md5').update(signatureString).digest('hex');
        console.log('🔍 FreeKassa - проверка подписи webhook:', {
            signatureString,
            received: signature,
            expected: expectedSignature,
            match: expectedSignature === signature.toLowerCase()
        });
        return expectedSignature === signature.toLowerCase();
    }
    /**
     * Создает счет на оплату через FreeKassa
     */
    async createInvoice(data) {
        try {
            console.log('🔄 Создаем счет в FreeKassa:', data);
            // Валидация обязательных параметров
            if (!data.invoiceId || !data.amount) {
                throw new Error('Обязательные параметры отсутствуют: invoiceId и amount');
            }
            if (data.amount <= 0) {
                throw new Error('Сумма должна быть больше 0');
            }
            const orderId = data.invoiceId;
            const amount = data.amount;
            const currency = 'RUB'; // Валюта (обязательный параметр)
            // Создаем подпись согласно документации FreeKassa
            const signature = this.createPaymentSignature(this.config.merchantId, amount, this.config.secretWord1, currency, orderId);
            console.log('🔍 FreeKassa - создание подписи:', {
                merchantId: this.config.merchantId,
                amount: amount.toFixed(2),
                currency,
                orderId,
                signature
            });
            // Формируем параметры для FreeKassa согласно документации
            const formData = {
                m: this.config.merchantId, // ID магазина (обязательно)
                oa: amount.toFixed(2), // Сумма платежа (обязательно)
                o: orderId, // ID заказа (обязательно)
                s: signature, // Подпись (обязательно)
                currency: currency, // Валюта (обязательно)
                em: data.userEmail || '', // Email покупателя (опционально)
                lang: 'ru', // Язык интерфейса
                i: data.description || '', // Описание заказа (опционально)
                us_participant: data.participantName, // Кастомное поле - имя участника
                us_masterclass: data.masterClassName, // Кастомное поле - название мастер-класса
            };
            console.log('✅ Данные формы FreeKassa созданы:', formData);
            // Правильный URL согласно документации
            const freekassaUrl = 'https://pay.fk.money/';
            return {
                success: true,
                paymentUrl: freekassaUrl,
                formData: formData,
                method: 'POST',
                invoiceId: orderId
            };
        }
        catch (error) {
            console.error('❌ Ошибка при создании счета в FreeKassa:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Неизвестная ошибка'
            };
        }
    }
    /**
     * Проверяет подпись уведомления от FreeKassa (webhook)
     * Параметры: MERCHANT_ID, AMOUNT, intid, MERCHANT_ORDER_ID, SIGN
     */
    verifyNotification(notification) {
        try {
            const merchantId = notification.MERCHANT_ID;
            const amount = notification.amount;
            const orderId = notification.invoiceId;
            const signature = notification.signature;
            if (!merchantId || !amount || !orderId || !signature) {
                console.error('❌ FreeKassa - неполные данные уведомления:', notification);
                return false;
            }
            return this.verifyWebhookSignature(merchantId, amount, this.config.secretWord2, orderId, signature);
        }
        catch (error) {
            console.error('❌ Ошибка при проверке подписи FreeKassa:', error);
            return false;
        }
    }
    /**
     * Проверяет подпись уведомления об успешной оплате (SuccessURL)
     * Используется та же логика, что и для webhook
     */
    verifySuccessNotification(notification) {
        return this.verifyNotification(notification);
    }
    /**
     * Создает возврат средств через FreeKassa API
     * Используется POST /orders/refund согласно документации
     */
    async createRefund(data) {
        try {
            console.log('🔄 Создаем возврат через FreeKassa API:', data);
            // Проверяем наличие необходимых данных
            if (!data.opKey || !data.refundSum) {
                return {
                    success: false,
                    error: 'Отсутствуют обязательные данные для возврата'
                };
            }
            // Формируем данные для API возврата FreeKassa
            const refundData = {
                order_id: data.opKey,
                amount: data.refundSum.toFixed(2)
            };
            // Создаем подпись для API запроса (HMAC-SHA256)
            const signature = this.createApiSignature(refundData);
            console.log('🔍 Данные для возврата FreeKassa:', { ...refundData, signature });
            // Отправляем запрос к API FreeKassa (правильный endpoint)
            const response = await fetch('https://api.fk.life/v1/orders/refund', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ ...refundData, signature })
            });
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const result = await response.json();
            console.log('✅ Результат возврата FreeKassa:', result);
            if (result.status === 'success' || result.success) {
                return {
                    success: true,
                    message: result.message || 'Возврат успешно инициирован',
                    requestId: result.refund_id || result.id || data.opKey
                };
            }
            else {
                return {
                    success: false,
                    error: result.message || result.error || 'Ошибка при создании возврата'
                };
            }
        }
        catch (error) {
            console.error('❌ Ошибка при создании возврата через FreeKassa:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Неизвестная ошибка'
            };
        }
    }
    /**
     * Получает статус возврата через FreeKassa API
     * Используется GET /orders согласно документации (проверка статуса по order_id)
     */
    async getRefundStatus(requestId) {
        try {
            console.log('🔄 Получаем статус возврата FreeKassa:', requestId);
            // Формируем данные для запроса
            const queryData = {
                order_id: requestId
            };
            // Создаем подпись для API запроса
            const signature = this.createApiSignature(queryData);
            // Отправляем запрос к API FreeKassa (правильный endpoint)
            const response = await fetch(`https://api.fk.life/v1/orders?order_id=${requestId}&signature=${signature}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            if (!response.ok) {
                console.error('❌ HTTP ошибка получения статуса возврата:', response.status);
                return null;
            }
            const result = await response.json();
            console.log('✅ Статус возврата FreeKassa:', result);
            if (result.status === 'success' && result.data) {
                return {
                    requestId: requestId,
                    amount: parseFloat(result.data.amount) || 0,
                    status: result.data.status || 'unknown'
                };
            }
            return null;
        }
        catch (error) {
            console.error('❌ Ошибка при получении статуса возврата FreeKassa:', error);
            return null;
        }
    }
    /**
     * Проверяет возможность возврата для даты мастер-класса
     * Возврат возможен только за 3 часа до мастер-класса
     */
    isRefundAvailable(workshopDate) {
        try {
            const workshopDateTime = new Date(workshopDate);
            const now = new Date();
            const timeDiff = workshopDateTime.getTime() - now.getTime();
            const hoursDiff = timeDiff / (1000 * 60 * 60);
            // Возврат возможен только если до мастер-класса больше 3 часов
            return hoursDiff > 3;
        }
        catch (error) {
            console.error('❌ Ошибка при проверке возможности возврата:', error);
            return false;
        }
    }
    /**
     * Проверяет, доступна ли оплата для пользователя
     * FreeKassa доступна для всех пользователей
     */
    isPaymentAvailable(userData) {
        return true;
    }
    /**
     * FreeKassa не использует OpKey для возвратов
     */
    async getOpKeyForRefund(invoiceId) {
        console.warn('⚠️ FreeKassa не использует OpKey для возвратов');
        return null;
    }
}
export const freekassaProvider = new FreekassaProvider();
//# sourceMappingURL=FreekassaProvider.js.map