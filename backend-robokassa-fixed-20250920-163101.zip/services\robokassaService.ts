/**
 * @file: robokassaService.ts
 * @description: Сервис для интеграции с Robokassa
 * @dependencies: types/robokassa.ts, crypto, jwt
 * @created: 2025-01-26
 */

import crypto from 'crypto';
import jwt from 'jsonwebtoken';
// @ts-expect-error - xml2js не имеет типов для ES modules
import { parseString } from 'xml2js';
import {
    RobokassaJWTHeader,
    RobokassaJWTPayload,
    RobokassaInvoiceItem,
    RobokassaCreateInvoiceResponse,
    RobokassaResultNotification,
    RobokassaJWSNotification,
    RobokassaRefundRequest,
    RobokassaRefundResponse,
    RobokassaRefundStatus,
    RobokassaConfig,
    CreateRobokassaInvoiceData
} from '../types/robokassa.js';

export class RobokassaService {
    private config: RobokassaConfig;

    constructor() {
        this.config = {
            merchantLogin: process.env.ROBOKASSA_MERCHANT_LOGIN || 'waxhands.ru',
            password1: process.env.ROBOKASSA_PASSWORD_1 || '',
            password2: process.env.ROBOKASSA_PASSWORD_2 || '',
            password3: process.env.ROBOKASSA_PASSWORD_3 || '',
            testMode: process.env.ROBOKASSA_TEST_MODE === 'true',
            successUrl: process.env.ROBOKASSA_SUCCESS_URL || 'https://waxhands.ru/payment/robokassa/success',
            failUrl: process.env.ROBOKASSA_FAIL_URL || 'https://waxhands.ru/payment/robokassa/fail',
            resultUrl: process.env.ROBOKASSA_RESULT_URL || 'https://waxhands.ru/api/robokassa/payment-webhook/robokassa',
            algorithm: (process.env.ROBOKASSA_ALGORITHM as 'MD5' | 'RIPEMD160' | 'SHA1' | 'SHA256' | 'SHA384' | 'SHA512') || 'MD5'
        };
    }

    /**
     * Создает JWT токен для Robokassa API
     */
    private createJWTToken(payload: RobokassaJWTPayload): string {
        const header: RobokassaJWTHeader = {
            typ: 'JWT',
            alg: this.config.algorithm
        };

        // Кодируем header и payload в Base64Url
        const encodedHeader = this.base64UrlEncode(JSON.stringify(header));
        const encodedPayload = this.base64UrlEncode(JSON.stringify(payload));

        // Создаем строку для подписи
        const signatureString = `${encodedHeader}.${encodedPayload}`;

        // Создаем подпись
        const secretKey = `${this.config.merchantLogin}:${this.config.password1}`;
        const signature = this.createSignature(signatureString, secretKey);

        return `${signatureString}.${signature}`;
    }

    /**
     * Создает подпись для строки (MD5 для Robokassa, HMAC для JWT)
     */
    private createSignature(data: string, secret: string, useMD5: boolean = false): string {
        if (useMD5) {
            // Для Robokassa используем обычный MD5 хеш
            return crypto.createHash('md5').update(data).digest('hex');
        }

        // Для JWT используем HMAC
        switch (this.config.algorithm) {
            case 'MD5':
                return crypto.createHmac('md5', secret).update(data).digest('base64');
            case 'SHA1':
                return crypto.createHmac('sha1', secret).update(data).digest('base64');
            case 'SHA256':
                return crypto.createHmac('sha256', secret).update(data).digest('base64');
            case 'SHA384':
                return crypto.createHmac('sha384', secret).update(data).digest('base64');
            case 'SHA512':
                return crypto.createHmac('sha512', secret).update(data).digest('base64');
            case 'RIPEMD160':
                return crypto.createHmac('ripemd160', secret).update(data).digest('base64');
            default:
                return crypto.createHmac('md5', secret).update(data).digest('base64');
        }
    }

    /**
     * Кодирует строку в Base64Url
     */
    private base64UrlEncode(str: string): string {
        return Buffer.from(str)
            .toString('base64')
            .replace(/\+/g, '-')
            .replace(/\//g, '_')
            .replace(/=/g, '');
    }

    /**
     * Декодирует Base64Url строку
     */
    private base64UrlDecode(str: string): string {
        // Добавляем padding если нужно
        const padded = str + '='.repeat((4 - str.length % 4) % 4);
        return Buffer.from(padded.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString();
    }

    /**
     * Создает фискальный чек для Robokassa
     */
    private createReceipt(data: CreateRobokassaInvoiceData): string {
        const items: Array<{
            name: string;
            quantity: number;
            sum: number;
            payment_method: string;
            payment_object: string;
            tax: string;
        }> = [];

        // Создаем одну позицию с общей суммой согласно документации
        // Сумма всех позиций в чеке должна быть равна сумме операции
        items.push({
            name: `Мастер-класс "${data.masterClassName}"`,
            quantity: 1,
            sum: data.amount, // Используем общую сумму
            payment_method: "full_prepayment", // Предоплата 100%
            payment_object: "service", // Услуга
            tax: "vat20" // НДС 20%
        });

        return JSON.stringify({
            sno: 'osn', // Общая система налогообложения
            items: items
        });
    }

    /**
     * Создает URL-кодированную строку для Receipt
     */
    private createReceiptUrlEncoded(data: CreateRobokassaInvoiceData): string {
        const receipt = this.createReceipt(data);
        return encodeURIComponent(receipt);
    }

    /**
     * Создает счет в Robokassa с правильной фискализацией
     */
    async createInvoice(data: CreateRobokassaInvoiceData): Promise<RobokassaCreateInvoiceResponse> {
        try {
            console.log('🔄 Создаем счет в Robokassa с фискализацией:', data);

            // Формируем краткое описание (максимум 100 символов для Robokassa)
            const description = `Мастер-класс "${data.masterClassName}"`;

            // Создаем уникальный ID счета
            const invId = parseInt(data.invoiceId.replace(/-/g, '').substring(0, 10), 16);

            // Создаем фискальный чек (обязательно для ФЗ-54)
            const receipt = this.createReceipt(data);

            console.log('🧾 Фискальный чек:', receipt);

            // Правильная подпись с фискализацией: MerchantLogin:OutSum:InvId:Receipt:Пароль#1
            const signatureString = `${this.config.merchantLogin}:${data.amount}:${invId}:${receipt}:${this.config.password1}`;
            const signature = this.createSignature(signatureString, '', true); // Используем MD5

            console.log('🔍 Подпись рассчитана С фискализацией для:', signatureString);
            console.log('🔍 Полученная подпись:', signature);

            // Создаем HTML форму для POST запроса (рекомендуется для длинных Receipt)
            const formData: {
                MerchantLogin: string;
                OutSum: string;
                InvoiceID: string;
                Receipt: string;
                Description: string;
                SignatureValue: string;
                Culture: string;
                Encoding: string;
                IsTest?: string;
            } = {
                MerchantLogin: this.config.merchantLogin,
                OutSum: data.amount.toString(),
                InvoiceID: invId.toString(),
                Receipt: receipt,
                Description: description,
                SignatureValue: signature,
                Culture: 'ru',
                Encoding: 'utf-8'
            };

            // Добавляем тестовый режим если включен
            if (this.config.testMode) {
                formData.IsTest = '1';
                console.log('🧪 Создаем тестовую форму на оплату С фискализацией');
            } else {
                console.log('🏪 Создаем продакшн форму на оплату С фискализацией');
            }

            console.log('✅ Данные формы созданы:', formData);

            return {
                success: true,
                invoiceUrl: 'https://auth.robokassa.ru/Merchant/Index.aspx',
                invoiceId: invId.toString(),
                formData: formData // Добавляем данные формы для POST запроса
            };

        } catch (error) {
            console.error('❌ Ошибка при создании счета в Robokassa:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Неизвестная ошибка'
            };
        }
    }

    /**
     * Проверяет подпись уведомления от Robokassa (ResultURL)
     */
    verifyResultSignature(notification: RobokassaResultNotification): boolean {
        try {
            const { OutSum, InvId, SignatureValue, ...shpParams } = notification;

            // Сортируем Shp параметры по алфавиту
            const sortedShpParams = Object.keys(shpParams)
                .filter(key => key.startsWith('Shp_'))
                .sort()
                .map(key => `${key}= ${shpParams[key]}`); // ВАЖНО: пробел после знака равенства!

            // Формируем строку для проверки подписи согласно документации
            // База: OutSum:InvId:Пароль#2:[Пользовательские параметры]
            const signatureString = sortedShpParams.length > 0
                ? `${OutSum}:${InvId}:${this.config.password2}:${sortedShpParams.join(':')}`
                : `${OutSum}:${InvId}:${this.config.password2}`;

            // Создаем подпись (MD5 в верхнем регистре)
            const expectedSignature = this.createSignature(signatureString, '', true).toUpperCase();

            console.log('🔍 Проверка подписи Robokassa (ResultURL):', {
                signatureString,
                received: SignatureValue,
                expected: expectedSignature,
                match: expectedSignature === SignatureValue.toUpperCase()
            });

            return expectedSignature === SignatureValue.toUpperCase();
        } catch (error) {
            console.error('❌ Ошибка при проверке подписи:', error);
            return false;
        }
    }

    /**
     * Проверяет подпись уведомления SuccessURL (возврат пользователя после оплаты)
     */
    verifySuccessSignature(notification: { OutSum: string; InvId: string; SignatureValue: string;[key: string]: string }): boolean {
        try {
            const { OutSum, InvId, SignatureValue, ...shpParams } = notification;

            // Сортируем Shp параметры по алфавиту
            const sortedShpParams = Object.keys(shpParams)
                .filter(key => key.startsWith('Shp_'))
                .sort()
                .map(key => `${key}= ${shpParams[key]}`); // ВАЖНО: пробел после знака равенства!

            // Формируем строку для проверки подписи согласно документации
            // База: OutSum:InvId:Пароль#1:[Пользовательские параметры]
            const signatureString = sortedShpParams.length > 0
                ? `${OutSum}:${InvId}:${this.config.password1}:${sortedShpParams.join(':')}`
                : `${OutSum}:${InvId}:${this.config.password1}`;

            // Создаем подпись (MD5 в верхнем регистре)
            const expectedSignature = this.createSignature(signatureString, '', true).toUpperCase();

            console.log('🔍 Проверка подписи Robokassa (SuccessURL):', {
                signatureString,
                received: SignatureValue,
                expected: expectedSignature,
                match: expectedSignature === SignatureValue.toUpperCase()
            });

            return expectedSignature === SignatureValue.toUpperCase();
        } catch (error) {
            console.error('❌ Ошибка при проверке подписи SuccessURL:', error);
            return false;
        }
    }

    /**
     * Проверяет подпись JWS уведомления
     */
    verifyJWSNotification(jwsToken: string): RobokassaJWSNotification | null {
        try {
            const [headerB64, payloadB64, signatureB64] = jwsToken.split('.');

            if (!headerB64 || !payloadB64 || !signatureB64) {
                throw new Error('Invalid JWS format');
            }

            // Декодируем header и payload
            const header = JSON.parse(this.base64UrlDecode(headerB64));
            const payload = JSON.parse(this.base64UrlDecode(payloadB64));

            // Проверяем подпись
            const signatureString = `${headerB64}.${payloadB64}`;
            const expectedSignature = this.createSignature(signatureString, this.config.password2, false);

            if (expectedSignature !== signatureB64) {
                console.error('❌ Неверная подпись JWS уведомления');
                return null;
            }

            return {
                header,
                data: payload
            };
        } catch (error) {
            console.error('❌ Ошибка при проверке JWS уведомления:', error);
            return null;
        }
    }

    /**
     * Инициирует возврат средств
     */
    async createRefund(refundData: RobokassaRefundRequest): Promise<RobokassaRefundResponse> {
        try {
            console.log('🔄 Создаем возврат в Robokassa:', refundData);

            const payload = {
                OpKey: refundData.OpKey,
                RefundSum: refundData.RefundSum,
                InvoiceItems: refundData.InvoiceItems
            };

            // Создаем JWT токен для возврата
            const jwtToken = jwt.sign(payload, this.config.password3, { algorithm: 'HS256' });

            const response = await fetch('https://services.robokassa.ru/RefundService/Refund/Create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ token: jwtToken })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();

            console.log('✅ Результат создания возврата:', result);

            return {
                success: result.success,
                message: result.message,
                requestId: result.requestId
            };

        } catch (error) {
            console.error('❌ Ошибка при создании возврата:', error);
            return {
                success: false,
                message: error instanceof Error ? error.message : 'Неизвестная ошибка'
            };
        }
    }

    /**
     * Получает статус возврата
     */
    async getRefundStatus(requestId: string): Promise<RobokassaRefundStatus | null> {
        try {
            console.log('🔄 Получаем статус возврата:', requestId);

            const response = await fetch(`https://services.robokassa.ru/RefundService/Refund/GetState?id=${requestId}`);

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();

            if (result.message) {
                console.error('❌ Ошибка получения статуса возврата:', result.message);
                return null;
            }

            return {
                requestId: result.requestId,
                amount: result.amount,
                label: result.label
            };

        } catch (error) {
            console.error('❌ Ошибка при получении статуса возврата:', error);
            return null;
        }
    }

    /**
     * Проверяет статус операции через XML API
     */
    async checkOperationStatus(invoiceId: number): Promise<{
        success: boolean;
        status?: number;
        description?: string | undefined;
        opKey?: string | undefined;
        outSum?: number | undefined;
        error?: string;
    }> {
        try {
            console.log('🔄 Проверяем статус операции:', invoiceId);

            // Создаем подпись для запроса
            const signatureString = `${this.config.merchantLogin}:${invoiceId}:${this.config.password2}`;
            const signature = this.createSignature(signatureString, '', true);

            const url = `https://auth.robokassa.ru/Merchant/WebService/Service.asmx/OpStateExt?` +
                `MerchantLogin=${this.config.merchantLogin}&` +
                `InvoiceID=${invoiceId}&` +
                `Signature=${signature}`;

            console.log('🔍 Запрос статуса операции:', url);

            const response = await fetch(url);
            const xmlText = await response.text();

            console.log('📄 Ответ XML API:', xmlText);

            // Парсим XML ответ с помощью xml2js
            return new Promise((resolve) => {
                parseString(xmlText, (err: Error | null, result: unknown) => {
                    if (err) {
                        console.error('❌ Ошибка парсинга XML:', err);
                        resolve({
                            success: false,
                            error: 'Ошибка парсинга XML ответа'
                        });
                        return;
                    }

                    try {
                        const parsedResult = result as Record<string, unknown>;
                        const operationStateResponse = parsedResult['OperationStateResponse'] as Record<string, unknown[]>;
                        const resultInfo = operationStateResponse['Result']?.[0] as Record<string, string[]> | undefined;

                        if (!resultInfo) {
                            resolve({
                                success: false,
                                error: 'Неверный формат XML ответа'
                            });
                            return;
                        }

                        const resultCode = resultInfo['Code']?.[0];
                        const resultDescription = resultInfo['Description']?.[0];

                        if (resultCode !== '0') {
                            resolve({
                                success: false,
                                error: resultDescription || 'Неизвестная ошибка'
                            });
                            return;
                        }

                        const stateInfo = operationStateResponse['State']?.[0] as Record<string, string[]> | undefined;
                        const info = operationStateResponse['Info']?.[0] as Record<string, string[]> | undefined;

                        if (!stateInfo || !info) {
                            resolve({
                                success: false,
                                error: 'Неверный формат XML ответа'
                            });
                            return;
                        }

                        const stateCode = stateInfo['Code']?.[0];
                        const opKey = info['OpKey']?.[0];
                        const outSum = info['OutSum']?.[0] ? parseFloat(info['OutSum'][0]) : undefined;

                        if (!stateCode) {
                            resolve({
                                success: false,
                                error: 'Неверный формат XML ответа'
                            });
                            return;
                        }

                        resolve({
                            success: true,
                            status: parseInt(stateCode),
                            description: resultDescription,
                            opKey: opKey,
                            outSum: outSum
                        });
                    } catch (parseError) {
                        console.error('❌ Ошибка обработки XML:', parseError);
                        resolve({
                            success: false,
                            error: 'Ошибка обработки XML ответа'
                        });
                    }
                });
            });

        } catch (error) {
            console.error('❌ Ошибка при проверке статуса операции:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Неизвестная ошибка'
            };
        }
    }

    /**
     * Создает данные для iframe оплаты (открытие в новом окне)
     */
    createIframePaymentData(data: CreateRobokassaInvoiceData): {
        success: boolean;
        iframeData?: {
            merchantLogin: string;
            outSum: string;
            invId: string;
            description: string;
            receipt: string;
            signatureValue: string;
            culture: string;
            encoding: string;
            isTest?: string;
        };
        error?: string;
    } {
        try {
            console.log('🔄 Создаем данные для iframe оплаты:', data);

            // Формируем краткое описание (максимум 100 символов для Robokassa)
            const description = `Мастер-класс "${data.masterClassName}"`;

            // Создаем уникальный ID счета
            const invId = parseInt(data.invoiceId.replace(/-/g, '').substring(0, 10), 16);

            // Создаем фискальный чек (обязательно для ФЗ-54)
            const receipt = this.createReceipt(data);

            console.log('🧾 Фискальный чек для iframe:', receipt);

            // Правильная подпись с фискализацией: MerchantLogin:OutSum:InvId:Receipt:Пароль#1
            const signatureString = `${this.config.merchantLogin}:${data.amount}:${invId}:${receipt}:${this.config.password1}`;
            const signature = this.createSignature(signatureString, '', true); // Используем MD5

            console.log('🔍 Подпись для iframe рассчитана С фискализацией для:', signatureString);
            console.log('🔍 Полученная подпись:', signature);

            const iframeData: {
                merchantLogin: string;
                outSum: string;
                invId: string;
                description: string;
                receipt: string;
                signatureValue: string;
                culture: string;
                encoding: string;
                isTest?: string;
            } = {
                merchantLogin: this.config.merchantLogin,
                outSum: data.amount.toString(),
                invId: invId.toString(),
                description: description,
                receipt: receipt, // Для iframe используем не URL-кодированный receipt
                signatureValue: signature,
                culture: 'ru',
                encoding: 'utf-8'
            };

            // Добавляем тестовый режим если включен
            if (this.config.testMode) {
                iframeData.isTest = '1';
            }

            console.log('✅ Данные для iframe созданы:', iframeData);

            return {
                success: true,
                iframeData
            };

        } catch (error) {
            console.error('❌ Ошибка при создании данных для iframe:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Неизвестная ошибка'
            };
        }
    }

    /**
     * Проверяет, доступна ли оплата для пользователя (только для Сафонова)
     */
    isPaymentAvailableForUser(userData: { surname?: string; phone?: string }): boolean {
        // Проверяем по фамилии и телефону для Сафонова
        const allowedUser = {
            surname: 'Сафонов',
            phone: '+79241002233'
        };

        return userData.surname === allowedUser.surname && userData.phone === allowedUser.phone;
    }
}

export const robokassaService = new RobokassaService();
