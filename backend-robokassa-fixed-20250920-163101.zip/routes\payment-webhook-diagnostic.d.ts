/**
 * @file: payment-webhook-diagnostic.ts
 * @description: Диагностический webhook для анализа уведомлений платежных систем
 * @dependencies: Router, types
 * @created: 2025-01-26
 */
declare const router: import("@types/express-serve-static-core/index.js").Router;
export default router;
//# sourceMappingURL=payment-webhook-diagnostic.d.ts.map