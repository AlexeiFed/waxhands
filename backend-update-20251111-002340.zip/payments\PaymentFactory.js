/**
 * @file: PaymentFactory.ts
 * @description: Фабрика для платежного провайдера Robokassa
 * @dependencies: IPaymentProvider, RobokassaProvider
 * @created: 2025-10-16
 */
import { RobokassaProvider } from './providers/RobokassaProvider.js';
/**
 * Фабрика платежных провайдеров (только Robokassa)
 */
export class PaymentFactory {
    static instance;
    currentProvider;
    constructor() {
        // Всегда используем Robokassa
        this.currentProvider = new RobokassaProvider();
        console.log(`🏪 PaymentFactory: Используется провайдер ${this.currentProvider.providerName}`);
    }
    /**
     * Получает единственный экземпляр фабрики (Singleton)
     */
    static getInstance() {
        if (!PaymentFactory.instance) {
            PaymentFactory.instance = new PaymentFactory();
        }
        return PaymentFactory.instance;
    }
    /**
     * Получает текущий платежный провайдер (всегда Robokassa)
     */
    getProvider() {
        return this.currentProvider;
    }
    /**
     * Получает Robokassa провайдер
     */
    getRobokassaProvider() {
        return this.currentProvider;
    }
}
/**
 * Экспортируем единственный экземпляр фабрики
 */
export const paymentFactory = PaymentFactory.getInstance();
/**
 * Вспомогательная функция для получения текущего провайдера
 */
export function getPaymentProvider() {
    return paymentFactory.getProvider();
}
//# sourceMappingURL=PaymentFactory.js.map