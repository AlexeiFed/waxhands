/**
 * @file: PaymentFactory.ts
 * @description: Фабрика для выбора платежного провайдера (Robokassa, FreeKassa и др.)
 * @dependencies: IPaymentProvider, RobokassaProvider, FreekassaProvider
 * @created: 2025-10-16
 */
import { RobokassaProvider } from './providers/RobokassaProvider.js';
import { FreekassaProvider } from './providers/FreekassaProvider.js';
/**
 * Фабрика платежных провайдеров
 * Позволяет легко переключаться между различными платежными системами через переменную окружения
 */
export class PaymentFactory {
    static instance;
    currentProvider;
    providerType;
    constructor() {
        // Получаем тип провайдера из переменной окружения
        const providerEnv = (process.env.PAYMENT_PROVIDER || 'robokassa').toLowerCase();
        // Валидация типа провайдера
        if (providerEnv !== 'robokassa' && providerEnv !== 'freekassa') {
            console.warn(`⚠️ Неизвестный провайдер: ${providerEnv}, используем Robokassa по умолчанию`);
            this.providerType = 'robokassa';
        }
        else {
            this.providerType = providerEnv;
        }
        // Создаем экземпляр провайдера
        this.currentProvider = this.createProvider(this.providerType);
        console.log(`🏪 PaymentFactory: Используется провайдер ${this.currentProvider.providerName}`);
    }
    /**
     * Получает единственный экземпляр фабрики (Singleton)
     */
    static getInstance() {
        if (!PaymentFactory.instance) {
            PaymentFactory.instance = new PaymentFactory();
        }
        return PaymentFactory.instance;
    }
    /**
     * Создает экземпляр провайдера по типу
     */
    createProvider(type) {
        switch (type) {
            case 'robokassa':
                return new RobokassaProvider();
            case 'freekassa':
                return new FreekassaProvider();
            default:
                console.warn(`⚠️ Неизвестный провайдер: ${type}, используем Robokassa`);
                return new RobokassaProvider();
        }
    }
    /**
     * Получает текущий платежный провайдер
     */
    getProvider() {
        return this.currentProvider;
    }
    /**
     * Получает тип текущего провайдера
     */
    getProviderType() {
        return this.providerType;
    }
    /**
     * Переключает провайдер (используется для тестирования или динамического переключения)
     */
    switchProvider(type) {
        console.log(`🔄 Переключение провайдера с ${this.currentProvider.providerName} на ${type}`);
        this.providerType = type;
        this.currentProvider = this.createProvider(type);
        console.log(`✅ Провайдер переключен на ${this.currentProvider.providerName}`);
    }
    /**
     * Проверяет, является ли текущий провайдер Robokassa
     */
    isRobokassa() {
        return this.providerType === 'robokassa';
    }
    /**
     * Проверяет, является ли текущий провайдер FreeKassa
     */
    isFreekassa() {
        return this.providerType === 'freekassa';
    }
    /**
     * Получает специфичный провайдер (для обратной совместимости)
     * @deprecated Используйте getProvider() для общих операций
     */
    getRobokassaProvider() {
        if (this.currentProvider instanceof RobokassaProvider) {
            return this.currentProvider;
        }
        console.warn('⚠️ Текущий провайдер не является Robokassa');
        return null;
    }
    /**
     * Получает специфичный провайдер FreeKassa (для обратной совместимости)
     * @deprecated Используйте getProvider() для общих операций
     */
    getFreekassaProvider() {
        if (this.currentProvider instanceof FreekassaProvider) {
            return this.currentProvider;
        }
        console.warn('⚠️ Текущий провайдер не является FreeKassa');
        return null;
    }
}
/**
 * Экспортируем единственный экземпляр фабрики
 */
export const paymentFactory = PaymentFactory.getInstance();
/**
 * Вспомогательная функция для получения текущего провайдера
 */
export function getPaymentProvider() {
    return paymentFactory.getProvider();
}
//# sourceMappingURL=PaymentFactory.js.map