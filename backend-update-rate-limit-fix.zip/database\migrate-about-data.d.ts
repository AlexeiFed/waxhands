/**
 * @file: migrate-about-data.ts
 * @description: Миграция существующих данных about из localStorage в БД
 * @dependencies: create-about-table.ts
 * @created: 2024-12-19
 */
declare function migrateAboutData(): Promise<boolean>;
export { migrateAboutData };
//# sourceMappingURL=migrate-about-data.d.ts.map