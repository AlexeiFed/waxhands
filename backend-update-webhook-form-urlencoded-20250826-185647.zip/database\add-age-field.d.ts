/**
 * @file: add-age-field.ts
 * @description: Миграция для добавления столбца age в таблицу users
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */
export declare const addAgeField: () => Promise<void>;
//# sourceMappingURL=add-age-field.d.ts.map