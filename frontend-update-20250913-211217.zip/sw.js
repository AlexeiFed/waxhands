// Service Worker для PWA
const CACHE_NAME = 'vostokovye-ruchki-v2.0.8'; // Принудительное обновление кэша
const urlsToCache = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icons/icon-72x72.png?v=2.0.8',
  '/icons/icon-96x96.png?v=2.0.8',
  '/icons/icon-128x128.png?v=2.0.8',
  '/icons/icon-144x144.png?v=2.0.8',
  '/icons/icon-152x152.png?v=2.0.8',
  '/icons/icon-180x180.png?v=2.0.8',
  '/icons/icon-192x192.png?v=2.0.8',
  '/icons/icon-192x192-maskable.png?v=2.0.8',
  '/icons/icon-384x384.png?v=2.0.8',
  '/icons/icon-512x512.png?v=2.0.8',
  '/icons/icon-512x512-maskable.png?v=2.0.8',
  '/icons/icon-1024x1024.png?v=2.0.8',
  '/icons/shortcut-96x96.png?v=2.0.8'
];

// Установка service worker
self.addEventListener('install', (event) => {
  event.waitUntil(
    // Принудительно очищаем все старые кэши
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          console.log('Clearing old cache on install:', cacheName);
          return caches.delete(cacheName);
        })
      );
    }).then(() => {
      // Открываем новый кэш
      return caches.open(CACHE_NAME);
    }).then((cache) => {
      console.log('Opened new cache:', CACHE_NAME);
      return cache.addAll(urlsToCache);
    }).then(() => {
      // Принудительно обновляем все клиенты
      return self.clients.claim();
    })
  );
});

// Перехват запросов
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        // Возвращаем кэшированный ответ или делаем сетевой запрос
        return response || fetch(event.request);
      })
  );
});

// Обновление кэша
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          // Удаляем ВСЕ старые кэши
          console.log('Deleting cache:', cacheName);
          return caches.delete(cacheName);
        })
      );
    }).then(() => {
      // Принудительно обновляем кэш для всех клиентов
      return self.clients.claim();
    })
  );
});

// Push уведомления
self.addEventListener('push', (event) => {
  const options = {
    body: event.data ? event.data.text() : 'Новое уведомление',
    icon: '/icons/icon-192x192.png?v=2.0.8',
    badge: '/icons/icon-72x72.png?v=2.0.8',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    },
    actions: [
      {
        action: 'explore',
        title: 'Открыть',
        icon: '/icons/icon-192x192.png?v=2.0.8'
      },
      {
        action: 'close',
        title: 'Закрыть',
        icon: '/icons/icon-192x192.png?v=2.0.8'
      }
    ]
  };

  event.waitUntil(
    self.registration.showNotification('Студия МК "Восковые ручки"', options)
  );
});

// Обработка кликов по уведомлениям
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  if (event.action === 'explore') {
    event.waitUntil(
      clients.openWindow('/')
    );
  }
}); 