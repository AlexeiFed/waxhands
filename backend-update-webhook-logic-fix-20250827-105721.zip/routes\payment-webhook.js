import { Router } from 'express';
import crypto from 'crypto';
import pool from '../database/connection.js';
import { updateInvoicePaymentStatus, findInvoiceByLabel, findInvoiceBySender } from '../services/paymentService.js';
import { sendPaymentSuccessNotification } from '../services/notificationService.js';
import { handlePaymentError } from '../services/retryService.js';
const router = Router();
// Функция для валидации подписи от ЮMoney
const validateYuMoneySignature = (req, body) => {
    try {
        // Получаем секретное слово из переменных окружения
        const notificationSecret = process.env.YUMONEY_NOTIFICATION_SECRET;
        if (!notificationSecret) {
            console.log('⚠️ YUMONEY_NOTIFICATION_SECRET не настроен, пропускаем валидацию');
            return true; // Пропускаем валидацию если секрет не настроен
        }
        // Формируем строку для проверки согласно документации ЮMoney
        const paramsString = [
            body.notification_type,
            body.operation_id,
            body.amount,
            body.currency,
            body.datetime,
            body.sender,
            body.codepro,
            notificationSecret,
            body.label || ''
        ].join('&');
        // Вычисляем SHA1 hash
        const calculatedHash = crypto.createHash('sha1').update(paramsString, 'utf8').digest('hex');
        // Сравниваем с полученным hash
        const isValid = calculatedHash === body.sha1_hash;
        console.log(`🔐 Валидация подписи ЮMoney: ${isValid ? 'УСПЕШНО' : 'ОШИБКА'}`);
        console.log(`📝 Строка для проверки: ${paramsString}`);
        console.log(`🔍 Вычисленный hash: ${calculatedHash}`);
        console.log(`📨 Полученный hash: ${body.sha1_hash}`);
        return isValid;
    }
    catch (error) {
        console.error('❌ Ошибка валидации подписи:', error);
        return false;
    }
};
// Webhook для ЮMoney
router.post('/yumoney', async (req, res) => {
    try {
        console.log('🔔 Webhook от ЮMoney получен:', JSON.stringify(req.body, null, 2));
        // Проверяем что это form-urlencoded данные
        if (req.headers['content-type']?.includes('application/x-www-form-urlencoded')) {
            const webhookData = req.body;
            // Валидируем подпись
            if (!validateYuMoneySignature(req, webhookData)) {
                console.error('❌ Неверная подпись от ЮMoney');
                res.status(401).json({
                    success: false,
                    error: 'Unauthorized - Invalid signature'
                });
                return;
            }
            // Проверяем тип уведомления
            if (webhookData.notification_type === 'p2p-incoming') {
                console.log(`💰 Получен P2P перевод: ${webhookData.amount} ${webhookData.currency}`);
                console.log(`👤 От: ${webhookData.sender}, Дата: ${webhookData.datetime}`);
                console.log(`🔍 Операция: ${webhookData.operation_id}, Метка: ${webhookData.label}`);
                // Логируем дополнительную информацию если доступна
                if (webhookData.lastname || webhookData.firstname) {
                    console.log(`👨‍💼 Отправитель: ${webhookData.lastname} ${webhookData.firstname} ${webhookData.fathersname || ''}`);
                }
                if (webhookData.email) {
                    console.log(`📧 Email: ${webhookData.email}`);
                }
                if (webhookData.phone) {
                    console.log(`📱 Телефон: ${webhookData.phone}`);
                }
                if (webhookData.city) {
                    console.log(`🏠 Адрес: ${webhookData.city}, ${webhookData.street} ${webhookData.building}`);
                }
                // Ищем счет по метке или отправителю
                let invoiceId = null;
                // Сначала ищем по точной метке
                if (webhookData.label && webhookData.label.trim() !== '') {
                    invoiceId = await findInvoiceByLabel(webhookData.label);
                    console.log(`🔍 Поиск по точной метке '${webhookData.label}': ${invoiceId ? 'найден' : 'не найден'}`);
                }
                // Если не найден по метке, ищем по части метки (для тестовых уведомлений)
                if (!invoiceId && webhookData.operation_id) {
                    // Для тестовых уведомлений ищем по operation_id в payment_label
                    try {
                        const result = await pool.query('SELECT id FROM invoices WHERE payment_label LIKE $1 AND status = $2', [`%${webhookData.operation_id}%`, 'pending']);
                        if (result.rows.length > 0) {
                            invoiceId = result.rows[0].id;
                            console.log(`🔍 Поиск по operation_id '${webhookData.operation_id}' в payment_label: найден счет ${invoiceId}`);
                        }
                    }
                    catch (error) {
                        console.error('❌ Ошибка поиска по operation_id:', error);
                    }
                }
                // Если все еще не найден, ищем по отправителю
                if (!invoiceId && webhookData.sender) {
                    invoiceId = await findInvoiceBySender(webhookData.sender);
                    console.log(`🔍 Поиск по отправителю '${webhookData.sender}': ${invoiceId ? 'найден' : 'не найден'}`);
                }
                // Для тестовых уведомлений выводим дополнительную информацию
                if (webhookData.test_notification === true) {
                    console.log(`🧪 Тестовое уведомление - operation_id: ${webhookData.operation_id}`);
                    console.log(`🧪 Доступные счета с pending статусом:`);
                    try {
                        const pendingInvoices = await pool.query('SELECT id, payment_label, amount, created_at FROM invoices WHERE status = $1 ORDER BY created_at DESC LIMIT 5', ['pending']);
                        pendingInvoices.rows.forEach(inv => {
                            console.log(`   - ${inv.id}: ${inv.payment_label} (${inv.amount} руб.)`);
                        });
                    }
                    catch (error) {
                        console.error('❌ Ошибка получения списка счетов:', error);
                    }
                }
                if (invoiceId) {
                    try {
                        // Обновляем статус счета
                        const paymentData = {
                            invoiceId,
                            paymentId: webhookData.operation_id,
                            amount: webhookData.amount,
                            currency: webhookData.currency,
                            paymentMethod: 'P2P transfer',
                            paymentDate: webhookData.datetime,
                            sender: webhookData.sender,
                            operationId: webhookData.operation_id,
                            label: webhookData.label
                        };
                        const result = await updateInvoicePaymentStatus(paymentData);
                        if (result.success) {
                            console.log(`✅ P2P перевод успешно обработан для счета ${invoiceId}`);
                            // Отправляем уведомления
                            try {
                                // Получаем userId из счета
                                const invoiceResult = await pool.query('SELECT user_id FROM invoices WHERE id = $1', [invoiceId]);
                                if (invoiceResult.rows.length > 0) {
                                    const userId = invoiceResult.rows[0].user_id;
                                    await sendPaymentSuccessNotification(userId, invoiceId, webhookData.amount, 'P2P transfer');
                                }
                            }
                            catch (notifyError) {
                                console.error('❌ Ошибка отправки уведомления:', notifyError);
                            }
                        }
                        else {
                            console.error(`❌ Ошибка обновления счета ${invoiceId}:`, result.error);
                            await handlePaymentError(webhookData.operation_id, result.error || 'Failed to update invoice', undefined, invoiceId);
                        }
                    }
                    catch (dbError) {
                        console.error(`❌ Ошибка обработки P2P перевода:`, dbError);
                        await handlePaymentError(webhookData.operation_id, dbError instanceof Error ? dbError.message : 'Database error', undefined, invoiceId);
                    }
                }
                else {
                    console.log(`ℹ️ Счет не найден для P2P перевода. Метка: ${webhookData.label}, Отправитель: ${webhookData.sender}`);
                }
                res.json({
                    success: true,
                    message: 'P2P transfer received',
                    amount: webhookData.amount,
                    currency: webhookData.currency,
                    sender: webhookData.sender,
                    operation_id: webhookData.operation_id,
                    label: webhookData.label,
                    invoice_found: !!invoiceId
                });
                return;
            }
            if (webhookData.notification_type === 'card-incoming') {
                console.log(`💳 Получен платеж картой: ${webhookData.amount} ${webhookData.currency}`);
                console.log(`🔍 Операция: ${webhookData.operation_id}, Метка: ${webhookData.label}`);
                console.log(`💰 Сумма списания: ${webhookData.withdraw_amount || 'не указана'}`);
                // Ищем счет по метке
                let invoiceId = null;
                if (webhookData.label) {
                    invoiceId = await findInvoiceByLabel(webhookData.label);
                }
                if (invoiceId) {
                    try {
                        // Обновляем статус счета
                        const paymentData = {
                            invoiceId,
                            paymentId: webhookData.operation_id,
                            amount: webhookData.amount,
                            currency: webhookData.currency,
                            paymentMethod: 'Card payment',
                            paymentDate: webhookData.datetime,
                            operationId: webhookData.operation_id,
                            label: webhookData.label
                        };
                        const result = await updateInvoicePaymentStatus(paymentData);
                        if (result.success) {
                            console.log(`✅ Платеж картой успешно обработан для счета ${invoiceId}`);
                            // Отправляем уведомления
                            try {
                                const invoiceResult = await pool.query('SELECT user_id FROM invoices WHERE id = $1', [invoiceId]);
                                if (invoiceResult.rows.length > 0) {
                                    const userId = invoiceResult.rows[0].user_id;
                                    await sendPaymentSuccessNotification(userId, invoiceId, webhookData.amount, 'Card payment');
                                }
                            }
                            catch (notifyError) {
                                console.error('❌ Ошибка отправки уведомления:', notifyError);
                            }
                        }
                        else {
                            console.error(`❌ Ошибка обновления счета ${invoiceId}:`, result.error);
                            await handlePaymentError(webhookData.operation_id, result.error || 'Failed to update invoice', undefined, invoiceId);
                        }
                    }
                    catch (dbError) {
                        console.error(`❌ Ошибка обработки платежа картой:`, dbError);
                        await handlePaymentError(webhookData.operation_id, dbError instanceof Error ? dbError.message : 'Database error', undefined, invoiceId);
                    }
                }
                else {
                    console.log(`ℹ️ Счет не найден для платежа картой. Метка: ${webhookData.label}`);
                }
                res.json({
                    success: true,
                    message: 'Card payment received',
                    amount: webhookData.amount,
                    currency: webhookData.currency,
                    operation_id: webhookData.operation_id,
                    label: webhookData.label,
                    withdraw_amount: webhookData.withdraw_amount,
                    invoice_found: !!invoiceId
                });
                return;
            }
            // Если это тестовое уведомление
            if (webhookData.test_notification === true) {
                console.log(`🧪 Тестовое уведомление от ЮMoney: ${webhookData.notification_type}`);
                res.json({
                    success: true,
                    message: 'Test notification received',
                    notification_type: webhookData.notification_type,
                    amount: webhookData.amount,
                    operation_id: webhookData.operation_id
                });
                return;
            }
            // Неизвестный тип уведомления
            console.log(`ℹ️ Неизвестный тип уведомления: ${webhookData.notification_type}`);
            res.status(200).json({
                success: true,
                message: 'Unknown notification type',
                notification_type: webhookData.notification_type
            });
            return;
        }
        // Если это JSON данные (платежи через форму)
        if (req.headers['content-type']?.includes('application/json')) {
            const jsonData = req.body;
            if ('event' in jsonData && jsonData.event === 'payment.succeeded') {
                const payment = jsonData.object;
                if (!payment) {
                    console.error('❌ Объект платежа не найден');
                    res.status(400).json({
                        success: false,
                        error: 'Missing payment object'
                    });
                    return;
                }
                const metadata = payment.metadata || {};
                const invoiceId = metadata.invoice_id;
                if (!invoiceId) {
                    console.error('❌ invoice_id не найден в metadata платежа');
                    res.status(400).json({
                        success: false,
                        error: 'Missing invoice_id in payment metadata'
                    });
                    return;
                }
                console.log(`💰 Обрабатываем успешную оплату для счета ${invoiceId}`);
                console.log(`🔍 Данные платежа:`, {
                    payment_id: payment.id,
                    amount: payment.amount.value,
                    currency: payment.amount.currency,
                    method: payment.payment_method.type,
                    created_at: payment.created_at,
                    captured_at: payment.captured_at
                });
                try {
                    // Обновляем статус счета
                    const paymentData = {
                        invoiceId,
                        paymentId: payment.id,
                        amount: payment.amount.value,
                        currency: payment.amount.currency,
                        paymentMethod: payment.payment_method.type,
                        paymentDate: payment.captured_at || payment.created_at,
                        operationId: payment.id
                    };
                    const result = await updateInvoicePaymentStatus(paymentData);
                    if (result.success) {
                        console.log(`✅ Счет ${invoiceId} успешно обновлен на статус 'paid'`);
                        // Отправляем уведомления
                        try {
                            const invoiceResult = await pool.query('SELECT user_id FROM invoices WHERE id = $1', [invoiceId]);
                            if (invoiceResult.rows.length > 0) {
                                const userId = invoiceResult.rows[0].user_id;
                                await sendPaymentSuccessNotification(userId, invoiceId, payment.amount.value, payment.payment_method.type);
                            }
                        }
                        catch (notifyError) {
                            console.error('❌ Ошибка отправки уведомления:', notifyError);
                        }
                        res.json({
                            success: true,
                            message: 'Payment processed successfully',
                            invoice_id: invoiceId,
                            payment_id: payment.id
                        });
                    }
                    else {
                        console.error(`❌ Не удалось обновить счет ${invoiceId}:`, result.error);
                        await handlePaymentError(payment.id, result.error || 'Failed to update invoice', undefined, invoiceId);
                        res.status(500).json({
                            success: false,
                            error: 'Failed to update invoice'
                        });
                    }
                }
                catch (dbError) {
                    console.error(`❌ Ошибка обработки платежа:`, dbError);
                    await handlePaymentError(payment.id, dbError instanceof Error ? dbError.message : 'Database error', undefined, invoiceId);
                    res.status(500).json({
                        success: false,
                        error: 'Internal server error'
                    });
                }
                return;
            }
            // Неизвестный JSON формат
            console.log(`ℹ️ Неизвестный JSON формат webhook'а`);
            res.status(200).json({
                success: true,
                message: 'Unknown JSON webhook format'
            });
            return;
        }
        // Неизвестный формат webhook'а
        console.log(`ℹ️ Неизвестный формат webhook'а от ЮMoney`);
        res.status(200).json({
            success: true,
            message: 'Unknown webhook format'
        });
    }
    catch (error) {
        console.error('❌ Ошибка обработки webhook\'а от ЮMoney:', error);
        // Обрабатываем ошибку с созданием записи о повторной попытке
        try {
            const operationId = req.body?.operation_id || req.body?.object?.id || 'unknown';
            await handlePaymentError(operationId, error instanceof Error ? error.message : 'Unknown error');
        }
        catch (retryError) {
            console.error('❌ Критическая ошибка при обработке ошибки:', retryError);
        }
        res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
});
export default router;
//# sourceMappingURL=payment-webhook.js.map