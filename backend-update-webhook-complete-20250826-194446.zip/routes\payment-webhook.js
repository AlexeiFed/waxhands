import { Router } from 'express';
import crypto from 'crypto';
const router = Router();
// Функция для валидации подписи от ЮMoney
const validateYuMoneySignature = (req, body) => {
    try {
        // Получаем секретное слово из переменных окружения
        const notificationSecret = process.env.YUMONEY_NOTIFICATION_SECRET;
        if (!notificationSecret) {
            console.log('⚠️ YUMONEY_NOTIFICATION_SECRET не настроен, пропускаем валидацию');
            return true; // Пропускаем валидацию если секрет не настроен
        }
        // Формируем строку для проверки согласно документации ЮMoney
        const paramsString = [
            body.notification_type,
            body.operation_id,
            body.amount,
            body.currency,
            body.datetime,
            body.sender,
            body.codepro,
            notificationSecret,
            body.label || ''
        ].join('&');
        // Вычисляем SHA1 hash
        const calculatedHash = crypto.createHash('sha1').update(paramsString, 'utf8').digest('hex');
        // Сравниваем с полученным hash
        const isValid = calculatedHash === body.sha1_hash;
        console.log(`🔐 Валидация подписи ЮMoney: ${isValid ? 'УСПЕШНО' : 'ОШИБКА'}`);
        console.log(`📝 Строка для проверки: ${paramsString}`);
        console.log(`🔍 Вычисленный hash: ${calculatedHash}`);
        console.log(`📨 Полученный hash: ${body.sha1_hash}`);
        return isValid;
    }
    catch (error) {
        console.error('❌ Ошибка валидации подписи:', error);
        return false;
    }
};
// Webhook для ЮMoney
router.post('/yumoney', async (req, res) => {
    try {
        console.log('🔔 Webhook от ЮMoney получен:', JSON.stringify(req.body, null, 2));
        // Проверяем что это form-urlencoded данные
        if (req.headers['content-type']?.includes('application/x-www-form-urlencoded')) {
            const webhookData = req.body;
            // Валидируем подпись
            if (!validateYuMoneySignature(req, webhookData)) {
                console.error('❌ Неверная подпись от ЮMoney');
                res.status(401).json({
                    success: false,
                    error: 'Unauthorized - Invalid signature'
                });
                return;
            }
            // Проверяем тип уведомления
            if (webhookData.notification_type === 'p2p-incoming') {
                console.log(`💰 Получен P2P перевод: ${webhookData.amount} ${webhookData.currency}`);
                console.log(`👤 От: ${webhookData.sender}, Дата: ${webhookData.datetime}`);
                console.log(`🔍 Операция: ${webhookData.operation_id}, Метка: ${webhookData.label}`);
                // Логируем дополнительную информацию если доступна
                if (webhookData.lastname || webhookData.firstname) {
                    console.log(`👨‍💼 Отправитель: ${webhookData.lastname} ${webhookData.firstname} ${webhookData.fathersname || ''}`);
                }
                if (webhookData.email) {
                    console.log(`📧 Email: ${webhookData.email}`);
                }
                if (webhookData.phone) {
                    console.log(`📱 Телефон: ${webhookData.phone}`);
                }
                if (webhookData.city) {
                    console.log(`🏠 Адрес: ${webhookData.city}, ${webhookData.street} ${webhookData.building}`);
                }
                // TODO: Обработать P2P перевод (найти счет по label или sender)
                // Пока что просто логируем и отвечаем успехом
                res.json({
                    success: true,
                    message: 'P2P transfer received',
                    amount: webhookData.amount,
                    currency: webhookData.currency,
                    sender: webhookData.sender,
                    operation_id: webhookData.operation_id,
                    label: webhookData.label
                });
                return;
            }
            if (webhookData.notification_type === 'card-incoming') {
                console.log(`💳 Получен платеж картой: ${webhookData.amount} ${webhookData.currency}`);
                console.log(`🔍 Операция: ${webhookData.operation_id}, Метка: ${webhookData.label}`);
                console.log(`💰 Сумма списания: ${webhookData.withdraw_amount || 'не указана'}`);
                // TODO: Обработать платеж картой (найти счет по label)
                res.json({
                    success: true,
                    message: 'Card payment received',
                    amount: webhookData.amount,
                    currency: webhookData.currency,
                    operation_id: webhookData.operation_id,
                    label: webhookData.label,
                    withdraw_amount: webhookData.withdraw_amount
                });
                return;
            }
            // Если это тестовое уведомление
            if (webhookData.test_notification === true) {
                console.log(`🧪 Тестовое уведомление от ЮMoney: ${webhookData.notification_type}`);
                res.json({
                    success: true,
                    message: 'Test notification received',
                    notification_type: webhookData.notification_type,
                    amount: webhookData.amount,
                    operation_id: webhookData.operation_id
                });
                return;
            }
            // Неизвестный тип уведомления
            console.log(`ℹ️ Неизвестный тип уведомления: ${webhookData.notification_type}`);
            res.status(200).json({
                success: true,
                message: 'Unknown notification type',
                notification_type: webhookData.notification_type
            });
            return;
        }
        // Если это JSON данные (платежи через форму)
        if (req.headers['content-type']?.includes('application/json')) {
            const jsonData = req.body;
            if ('event' in jsonData && jsonData.event === 'payment.succeeded') {
                const payment = jsonData.object;
                if (!payment) {
                    console.error('❌ Объект платежа не найден');
                    res.status(400).json({
                        success: false,
                        error: 'Missing payment object'
                    });
                    return;
                }
                const metadata = payment.metadata || {};
                const invoiceId = metadata.invoice_id;
                if (!invoiceId) {
                    console.error('❌ invoice_id не найден в metadata платежа');
                    res.status(400).json({
                        success: false,
                        error: 'Missing invoice_id in payment metadata'
                    });
                    return;
                }
                console.log(`💰 Обрабатываем успешную оплату для счета ${invoiceId}`);
                console.log(`🔍 Данные платежа:`, {
                    payment_id: payment.id,
                    amount: payment.amount.value,
                    currency: payment.amount.currency,
                    method: payment.payment_method.type,
                    created_at: payment.created_at,
                    captured_at: payment.captured_at
                });
                // TODO: Обновить статус счета в базе данных
                // Пока что просто логируем и отвечаем успехом
                res.json({
                    success: true,
                    message: 'Payment processed successfully',
                    invoice_id: invoiceId,
                    payment_id: payment.id
                });
                return;
            }
            // Неизвестный JSON формат
            console.log(`ℹ️ Неизвестный JSON формат webhook'а`);
            res.status(200).json({
                success: true,
                message: 'Unknown JSON webhook format'
            });
            return;
        }
        // Неизвестный формат webhook'а
        console.log(`ℹ️ Неизвестный формат webhook'а от ЮMoney`);
        res.status(200).json({
            success: true,
            message: 'Unknown webhook format'
        });
    }
    catch (error) {
        console.error('❌ Ошибка обработки webhook\'а от ЮMoney:', error);
        res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
});
export default router;
//# sourceMappingURL=payment-webhook.js.map