import { Router } from 'express';
import crypto from 'crypto';
import pool from '../database/connection.js';
import { updateInvoicePaymentStatus, findInvoiceByLabel, findInvoiceBySender } from '../services/paymentService.js';
import { sendPaymentSuccessNotification } from '../services/notificationService.js';
import { handlePaymentError } from '../services/retryService.js';
const router = Router();
// Функция для валидации подписи от ЮMoney
const validateYuMoneySignature = (req, body) => {
    try {
        // Получаем секретное слово из переменных окружения
        const notificationSecret = process.env.YUMONEY_NOTIFICATION_SECRET;
        if (!notificationSecret) {
            console.log('⚠️ YUMONEY_NOTIFICATION_SECRET не настроен, пропускаем валидацию');
            return true; // Пропускаем валидацию если секрет не настроен
        }
        // ИСПРАВЛЕНО: Правильный порядок параметров согласно документации ЮMoney
        // Формат: notification_type&operation_id&amount&currency&datetime&sender&codepro&notification_secret&label
        const paramsString = [
            body.notification_type,
            body.operation_id,
            body.amount,
            body.currency,
            body.datetime,
            body.sender,
            body.codepro,
            notificationSecret,
            body.label || ''
        ].join('&');
        // Вычисляем SHA1 hash
        const calculatedHash = crypto.createHash('sha1').update(paramsString, 'utf8').digest('hex');
        // Сравниваем с полученным hash
        const isValid = calculatedHash === body.sha1_hash;
        console.log(`🔐 Валидация подписи ЮMoney: ${isValid ? 'УСПЕШНО' : 'ОШИБКА'}`);
        console.log(`📝 Строка для проверки: ${paramsString}`);
        console.log(`🔍 Вычисленный hash: ${calculatedHash}`);
        console.log(`📨 Полученный hash: ${body.sha1_hash}`);
        return isValid;
    }
    catch (error) {
        console.error('❌ Ошибка валидации подписи:', error);
        return false;
    }
};
// Webhook для ЮMoney - УПРОЩЕННАЯ ВЕРСИЯ для диагностики
router.post('/yumoney', async (req, res) => {
    // ШАГ 1: Детальное логирование ВСЕГО входящего запроса
    console.log('=== WEBHOOK RECEIVED ===');
    console.log('Headers:', JSON.stringify(req.headers, null, 2));
    console.log('Raw Body:', req.body);
    console.log('Content-Type:', req.headers['content-type']);
    console.log('=======================');
    // ШАГ 2: Немедленно отвечаем 200 OK
    res.status(200).send('OK');
    // ШАГ 3: ВСЮ дальнейшую обработку выносим в асинхронную функцию
    processWebhookAsync(req.body).catch(console.error);
});
// Асинхронная обработка webhook'а
async function processWebhookAsync(body) {
    try {
        console.log('🔄 Начинаем обработку webhook\'а...');
        console.log('📦 Тело запроса:', body);
        // Проверяем что это form-urlencoded данные
        if (body.notification_type) {
            const webhookData = body;
            console.log(`📨 Тип уведомления: ${webhookData.notification_type}`);
            // КРИТИЧЕСКАЯ ПРОВЕРКА: codepro
            if (webhookData.codepro === true) {
                console.log('🚨 Платеж защищен кодом протекции (codepro=true). НЕ МОЖЕМ ОБРАБОТАТЬ АВТОМАТИЧЕСКИ!');
                console.log('💡 ЮMoney будет ждать вызов API метода accept-payment с верным кодом протекции');
                return;
            }
            // Валидируем подпись
            if (!validateYuMoneySignature({}, webhookData)) {
                console.error('❌ Неверная подпись от ЮMoney');
                return;
            }
            // Обрабатываем P2P переводы
            if (webhookData.notification_type === 'p2p-incoming') {
                await handleP2PTransfer(webhookData);
            }
            // Обрабатываем платежи картой
            else if (webhookData.notification_type === 'card-incoming') {
                await handleCardPayment(webhookData);
            }
            // Тестовые уведомления
            else if (webhookData.test_notification === true) {
                console.log(`🧪 Тестовое уведомление от ЮMoney: ${webhookData.notification_type}`);
            }
            // Неизвестный тип
            else {
                console.log(`ℹ️ Неизвестный тип уведомления: ${webhookData.notification_type}`);
            }
        }
        else {
            console.log('ℹ️ Неизвестный формат webhook\'а от ЮMoney');
        }
    }
    catch (error) {
        console.error('❌ Ошибка обработки webhook\'а:', error);
        // Обрабатываем ошибку с созданием записи о повторной попытке
        try {
            const operationId = body?.operation_id || body?.object?.id || 'unknown';
            await handlePaymentError(operationId, error instanceof Error ? error.message : 'Unknown error');
        }
        catch (retryError) {
            console.error('❌ Критическая ошибка при обработке ошибки:', retryError);
        }
    }
}
// Обработка P2P переводов
async function handleP2PTransfer(webhookData) {
    console.log(`💰 Получен P2P перевод: ${webhookData.amount} ${webhookData.currency}`);
    console.log(`👤 От: ${webhookData.sender}, Дата: ${webhookData.datetime}`);
    console.log(`🔍 Операция: ${webhookData.operation_id}, Метка: ${webhookData.label}`);
    // Логируем дополнительную информацию если доступна
    if (webhookData.lastname || webhookData.firstname) {
        console.log(`👨‍💼 Отправитель: ${webhookData.lastname} ${webhookData.firstname} ${webhookData.fathersname || ''}`);
    }
    if (webhookData.email) {
        console.log(`📧 Email: ${webhookData.email}`);
    }
    if (webhookData.phone) {
        console.log(`📱 Телефон: ${webhookData.phone}`);
    }
    if (webhookData.city) {
        console.log(`🏠 Адрес: ${webhookData.city}, ${webhookData.street} ${webhookData.building}`);
    }
    // Ищем счет по метке или отправителю
    let invoiceId = null;
    if (webhookData.label) {
        invoiceId = await findInvoiceByLabel(webhookData.label);
    }
    if (!invoiceId && webhookData.sender) {
        invoiceId = await findInvoiceBySender(webhookData.sender);
    }
    if (invoiceId) {
        try {
            // Обновляем статус счета
            const paymentData = {
                invoiceId,
                paymentId: webhookData.operation_id,
                amount: webhookData.amount,
                currency: webhookData.currency,
                paymentMethod: 'P2P transfer',
                paymentDate: webhookData.datetime,
                sender: webhookData.sender,
                operationId: webhookData.operation_id,
                label: webhookData.label
            };
            const result = await updateInvoicePaymentStatus(paymentData);
            if (result.success) {
                console.log(`✅ P2P перевод успешно обработан для счета ${invoiceId}`);
                // Отправляем уведомления
                try {
                    // Получаем userId из счета
                    const invoiceResult = await pool.query('SELECT user_id FROM invoices WHERE id = $1', [invoiceId]);
                    if (invoiceResult.rows.length > 0) {
                        const userId = invoiceResult.rows[0].user_id;
                        await sendPaymentSuccessNotification(userId, invoiceId, webhookData.amount, 'P2P transfer');
                    }
                }
                catch (notifyError) {
                    console.error('❌ Ошибка отправки уведомления:', notifyError);
                }
            }
            else {
                console.error(`❌ Ошибка обновления счета ${invoiceId}:`, result.error);
                await handlePaymentError(webhookData.operation_id, result.error || 'Failed to update invoice', undefined, invoiceId);
            }
        }
        catch (dbError) {
            console.error(`❌ Ошибка обработки P2P перевода:`, dbError);
            await handlePaymentError(webhookData.operation_id, dbError instanceof Error ? dbError.message : 'Database error', undefined, invoiceId);
        }
    }
    else {
        console.log(`ℹ️ Счет не найден для P2P перевода. Метка: ${webhookData.label}, Отправитель: ${webhookData.sender}`);
    }
}
// Обработка платежей картой
async function handleCardPayment(webhookData) {
    console.log(`💳 Получен платеж картой: ${webhookData.amount} ${webhookData.currency}`);
    console.log(`🔍 Операция: ${webhookData.operation_id}, Метка: ${webhookData.label}`);
    console.log(`💰 Сумма списания: ${webhookData.withdraw_amount || 'не указана'}`);
    // Ищем счет по метке
    let invoiceId = null;
    if (webhookData.label) {
        invoiceId = await findInvoiceByLabel(webhookData.label);
    }
    if (invoiceId) {
        try {
            // Обновляем статус счета
            const paymentData = {
                invoiceId,
                paymentId: webhookData.operation_id,
                amount: webhookData.amount,
                currency: webhookData.currency,
                paymentMethod: 'Card payment',
                paymentDate: webhookData.datetime,
                operationId: webhookData.operation_id,
                label: webhookData.label
            };
            const result = await updateInvoicePaymentStatus(paymentData);
            if (result.success) {
                console.log(`✅ Платеж картой успешно обработан для счета ${invoiceId}`);
                // Отправляем уведомления
                try {
                    const invoiceResult = await pool.query('SELECT user_id FROM invoices WHERE id = $1', [invoiceId]);
                    if (invoiceResult.rows.length > 0) {
                        const userId = invoiceResult.rows[0].user_id;
                        await sendPaymentSuccessNotification(userId, invoiceId, webhookData.amount, 'Card payment');
                    }
                }
                catch (notifyError) {
                    console.error('❌ Ошибка отправки уведомления:', notifyError);
                }
            }
            else {
                console.error(`❌ Ошибка обновления счета ${invoiceId}:`, result.error);
                await handlePaymentError(webhookData.operation_id, result.error || 'Failed to update invoice', undefined, invoiceId);
            }
        }
        catch (dbError) {
            console.error(`❌ Ошибка обработки платежа картой:`, dbError);
            await handlePaymentError(webhookData.operation_id, dbError instanceof Error ? dbError.message : 'Database error', undefined, invoiceId);
        }
    }
    else {
        console.log(`ℹ️ Счет не найден для платежа картой. Метка: ${webhookData.label}`);
    }
}
export default router;
//# sourceMappingURL=payment-webhook.js.map