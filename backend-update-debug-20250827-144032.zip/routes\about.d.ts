/**
 * @file: about.ts
 * @description: Маршруты для управления контентом страницы "О нас"
 * @dependencies: controllers/about.ts, middleware/auth.ts
 * @created: 2024-12-19
 */
declare const router: import("@types/express-serve-static-core/index.js").Router;
export default router;
//# sourceMappingURL=about.d.ts.map