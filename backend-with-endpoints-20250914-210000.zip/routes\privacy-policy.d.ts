/**
 * @file: privacy-policy.ts
 * @description: API роуты для управления политикой конфиденциальности
 * @dependencies: express, multer, path, fs, puppeteer
 * @created: 2024-12-25
 */
declare const router: import("@types/express-serve-static-core").Router;
export default router;
//# sourceMappingURL=privacy-policy.d.ts.map