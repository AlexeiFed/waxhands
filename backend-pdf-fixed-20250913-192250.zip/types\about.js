/**
 * @file: about.ts
 * @description: Типы для таблиц about и about_media
 * @dependencies: -
 * @created: 2024-12-19
 */
export {};
//# sourceMappingURL=about.js.map