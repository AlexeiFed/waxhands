/**
 * @file: payment-webhook-diagnostic.ts
 * @description: Диагностический webhook для тестирования уведомлений ЮMoney
 * @dependencies: express, crypto
 * @created: 2025-01-26
 */
import { Router } from 'express';
import crypto from 'crypto';
const router = Router();
// Диагностический webhook для ЮMoney
router.post('/yumoney-diagnostic', async (req, res) => {
    // ШАГ 1: Детальное логирование ВСЕГО входящего запроса
    console.log('\n🔍 === DIAGNOSTIC WEBHOOK RECEIVED ===');
    console.log('📅 Время:', new Date().toISOString());
    console.log('🌐 URL:', req.url);
    console.log('📋 Метод:', req.method);
    console.log('📨 Headers:', JSON.stringify(req.headers, null, 2));
    console.log('📦 Raw Body:', req.body);
    console.log('📝 Content-Type:', req.headers['content-type']);
    console.log('🔢 Content-Length:', req.headers['content-length']);
    console.log('🌍 User-Agent:', req.headers['user-agent']);
    console.log('📡 X-Forwarded-For:', req.headers['x-forwarded-for']);
    console.log('🔒 X-Real-IP:', req.headers['x-real-ip']);
    console.log('=====================================\n');
    // ШАГ 2: Немедленно отвечаем 200 OK
    res.status(200).send('OK');
    // ШАГ 3: Асинхронная диагностика
    processDiagnosticAsync(req.body, req.headers).catch(console.error);
});
// Асинхронная диагностика
async function processDiagnosticAsync(body, headers) {
    try {
        console.log('🔄 Начинаем диагностику webhook\'а...');
        // Проверяем наличие обязательных полей
        const requiredFields = ['notification_type', 'operation_id', 'amount', 'currency', 'datetime', 'sender', 'codepro', 'label', 'sha1_hash'];
        const missingFields = requiredFields.filter(field => !(field in body));
        if (missingFields.length > 0) {
            console.log('❌ Отсутствуют обязательные поля:', missingFields);
        }
        else {
            console.log('✅ Все обязательные поля присутствуют');
        }
        // Анализируем каждый параметр
        console.log('\n📊 Анализ параметров:');
        console.log('🔔 Тип уведомления:', body.notification_type);
        console.log('🆔 ID операции:', body.operation_id);
        console.log('💰 Сумма:', body.amount);
        console.log('💱 Валюта:', body.currency);
        console.log('📅 Дата/время:', body.datetime);
        console.log('👤 Отправитель:', body.sender);
        console.log('🔒 Защищен кодом:', body.codepro);
        console.log('🏷️ Метка:', body.label);
        console.log('🔐 SHA1 hash:', body.sha1_hash);
        console.log('🧪 Тестовое:', body.test_notification);
        console.log('❄️ Заморожен:', body.unaccepted);
        // Проверяем типы данных
        console.log('\n🔍 Проверка типов данных:');
        console.log('codepro тип:', typeof body.codepro, 'значение:', body.codepro);
        console.log('test_notification тип:', typeof body.test_notification, 'значение:', body.test_notification);
        console.log('unaccepted тип:', typeof body.unaccepted, 'значение:', body.unaccepted);
        // Проверяем codepro - критически важно!
        if (body.codepro === true) {
            console.log('\n🚨 ВНИМАНИЕ: Платеж защищен кодом протекции (codepro=true)');
            console.log('💡 Это означает, что ЮMoney НЕ будет автоматически зачислять деньги');
            console.log('🔑 Нужно вызвать API метод accept-payment с верным кодом протекции');
            console.log('❌ Автоматическая обработка НЕВОЗМОЖНА');
        }
        else if (body.codepro === false) {
            console.log('\n✅ Платеж НЕ защищен кодом протекции (codepro=false)');
            console.log('💚 Можно обрабатывать автоматически');
        }
        else {
            console.log('\n⚠️ Неопределенное значение codepro:', body.codepro);
        }
        // Проверяем подпись если есть секрет
        const notificationSecret = process.env.YUMONEY_NOTIFICATION_SECRET;
        if (notificationSecret) {
            console.log('\n🔐 Проверка подписи SHA1...');
            // Правильный порядок параметров согласно документации ЮMoney
            const paramsString = [
                body.notification_type,
                body.operation_id,
                body.amount,
                body.currency,
                body.datetime,
                body.sender,
                body.codepro,
                notificationSecret,
                body.label || ''
            ].join('&');
            const calculatedHash = crypto.createHash('sha1').update(paramsString, 'utf8').digest('hex');
            const isValid = calculatedHash === body.sha1_hash;
            console.log('📝 Строка для проверки:', paramsString);
            console.log('🔍 Вычисленный hash:', calculatedHash);
            console.log('📨 Полученный hash:', body.sha1_hash);
            console.log('✅ Подпись валидна:', isValid);
        }
        else {
            console.log('\n⚠️ YUMONEY_NOTIFICATION_SECRET не настроен, пропускаем проверку подписи');
        }
        // Анализ дополнительных полей
        if (body.lastname || body.firstname || body.email || body.phone) {
            console.log('\n👤 Контактная информация отправителя:');
            console.log('Фамилия:', body.lastname);
            console.log('Имя:', body.firstname);
            console.log('Отчество:', body.fathersname);
            console.log('Email:', body.email);
            console.log('Телефон:', body.phone);
        }
        if (body.city || body.street || body.building) {
            console.log('\n🏠 Адрес отправителя:');
            console.log('Город:', body.city);
            console.log('Улица:', body.street);
            console.log('Дом:', body.building);
            console.log('Корпус:', body.suite);
            console.log('Квартира:', body.flat);
            console.log('Индекс:', body.zip);
        }
        // Проверяем формат метки
        if (body.label) {
            console.log('\n🏷️ Анализ метки платежа:');
            console.log('Метка:', body.label);
            console.log('Длина:', body.label.length);
            console.log('Содержит INV-:', body.label.includes('INV-'));
            console.log('Содержит UUID:', /[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/i.test(body.label));
        }
        console.log('\n✅ Диагностика завершена');
    }
    catch (error) {
        console.error('❌ Ошибка диагностики:', error);
    }
}
// Тестовый endpoint для проверки
router.post('/yumoney-test', (req, res) => {
    console.log('🧪 Тестовый webhook получен');
    console.log('Тело:', req.body);
    res.status(200).json({
        success: true,
        message: 'Test webhook received',
        timestamp: new Date().toISOString(),
        body: req.body
    });
});
export default router;
//# sourceMappingURL=payment-webhook-diagnostic.js.map