/**
 * @file: payment-webhook-diagnostic.ts
 * @description: Диагностический webhook для тестирования уведомлений ЮMoney
 * @dependencies: express, crypto
 * @created: 2025-01-26
 */
declare const router: import("@types/express-serve-static-core").Router;
export default router;
//# sourceMappingURL=payment-webhook-diagnostic.d.ts.map