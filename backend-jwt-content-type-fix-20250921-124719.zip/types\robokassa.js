/**
 * @file: robokassa.ts
 * @description: Типы для интеграции с Robokassa
 * @dependencies: types/index.ts
 * @created: 2025-01-26
 */
export {};
//# sourceMappingURL=robokassa.js.map