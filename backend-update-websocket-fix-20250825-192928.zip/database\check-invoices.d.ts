/**
 * @file: check-invoices.ts
 * @description: Проверка структуры таблицы invoices
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */
export declare const checkInvoices: () => Promise<void>;
//# sourceMappingURL=check-invoices.d.ts.map