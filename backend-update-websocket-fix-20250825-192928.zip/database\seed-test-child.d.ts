/**
 * @file: seed-test-child.ts
 * @description: Скрипт для создания тестового ребенка
 * @dependencies: connection.ts
 * @created: 2024-12-19
 */
declare const seedTestChild: () => Promise<void>;
export { seedTestChild };
//# sourceMappingURL=seed-test-child.d.ts.map