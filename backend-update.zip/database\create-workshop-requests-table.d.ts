export function createWorkshopRequestsTable(): Promise<void>;
export default createWorkshopRequestsTable;
//# sourceMappingURL=create-workshop-requests-table.d.ts.map