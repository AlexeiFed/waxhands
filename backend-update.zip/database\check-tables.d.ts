export function checkTables(): Promise<void>;
//# sourceMappingURL=check-tables.d.ts.map