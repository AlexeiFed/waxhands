export function checkSchools(): Promise<void>;
//# sourceMappingURL=check-schools.d.ts.map