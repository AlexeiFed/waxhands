export function getAllSchools(req: any, res: any): Promise<void>;
export function getSchoolById(req: any, res: any): Promise<void>;
export function createSchool(req: any, res: any): Promise<void>;
export function updateSchool(req: any, res: any): Promise<void>;
export function deleteSchool(req: any, res: any): Promise<void>;
export function getSchoolClasses(req: any, res: any): Promise<void>;
export function searchSchools(req: any, res: any): Promise<void>;
//# sourceMappingURL=schools.d.ts.map