export class WebSocketManager {
    constructor(server: any);
    wss: import("ws").Server<typeof import("ws"), typeof import("http").IncomingMessage>;
    clients: Map<any, any>;
    eventQueue: any[];
    isProcessingEvents: boolean;
    setupWebSocketServer(): void;
    handleClientMessage(clientId: any, message: any): void;
    removeClient(clientId: any): void;
    broadcastEvent(event: any): void;
    sendToUsers(userIds: any, event: any): void;
    sendToRoles(roles: any, event: any): void;
    sendToSubscribers(channels: any, event: any): void;
    sendEventToClient(client: any, event: any): void;
    processEventQueue(): Promise<void>;
    getChannelsForEvent(event: any): string[];
    startHeartbeat(): void;
    startEventProcessor(): void;
    setupChatEventHandlers(): void;
    setupInvoiceEventHandlers(): void;
    setupMasterClassEventHandlers(): void;
    notifyChatMessage(chatId: any, message: any, senderId: any, senderType: any): void;
    notifyNewChat(chatId: any, userId: any, adminId: any, firstMessage: any): void;
    notifyUnreadCountUpdate(chatId: any): void;
    notifyChatStatusChange(chatId: any, status: any, adminId: any): void;
    notifyInvoiceUpdate(invoiceId: any, userId: any, status: any): void;
    notifyMasterClassUpdate(masterClassId: any, action: any): void;
    notifyWorkshopRequestUpdate(requestId: any, action: any, data: any): void;
    notifyWorkshopRequestStatusChange(requestId: any, newStatus: any, adminNotes: any): void;
    notifyWorkshopRequestCreated(requestId: any, requestData: any): void;
    notifyUserRegistration(userId: any, userRole: any): void;
    notifySystemNotification(message: any, level?: string): void;
    notifyAboutContentUpdate(contentId: any, action: any): void;
    notifyAboutMediaUpdate(mediaId: any, action: any, mediaData: any): void;
    notifyAboutMediaAdded(mediaData: any): void;
    notifyAboutMediaDeleted(mediaId: any): void;
    getStats(): {
        totalClients: number;
        adminClients: number;
        userClients: number;
        activeConnections: number;
        eventQueueLength: number;
    };
    cleanup(): void;
}
export let wsManager: any;
export function initializeWebSocketManager(server: any): Promise<any>;
//# sourceMappingURL=websocket-server.d.ts.map