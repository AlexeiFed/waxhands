export function checkServiceData(): Promise<void>;
//# sourceMappingURL=check-service-data.d.ts.map