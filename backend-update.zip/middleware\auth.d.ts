export function authenticateToken(req: any, res: any, next: any): void;
export function authorizeAdmin(req: any, res: any, next: any): void;
export function authorizeParentOrAdmin(req: any, res: any, next: any): void;
export function authorizeRoles(...roles: any[]): (req: any, res: any, next: any) => void;
export function authorizeChild(req: any, res: any, next: any): void;
export function authorizeExecutor(req: any, res: any, next: any): void;
export function requireRole(...roles: any[]): (req: any, res: any, next: any) => void;
export function authorizeResourceOwner(resourceUserIdField?: string): (req: any, res: any, next: any) => any;
export function logRequest(req: any, res: any, next: any): void;
export function errorHandler(err: any, req: any, res: any, next: any): any;
//# sourceMappingURL=auth.d.ts.map