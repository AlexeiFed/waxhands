export function updateDates(): Promise<void>;
//# sourceMappingURL=update-dates.d.ts.map