export class PaymentChecker {
    isRunning: boolean;
    checkInterval: number;
    /**
     * Запускает автоматическую проверку платежей
     */
    startPeriodicCheck(): Promise<void>;
    /**
     * Останавливает автоматическую проверку
     */
    stopPeriodicCheck(): void;
    /**
     * Проверяет все pending счета
     */
    checkAllPendingPayments(): Promise<{
        success: boolean;
        message: string;
        checkedInvoices: number;
        updatedInvoices: number;
    }>;
    /**
     * Проверяет конкретный счет по ID
     */
    checkInvoicePayment(invoiceId: any): Promise<{
        success: boolean;
        message: string;
        checkedInvoices: number;
        updatedInvoices: number;
    }>;
}
declare const _default: PaymentChecker;
export default _default;
//# sourceMappingURL=paymentChecker.d.ts.map