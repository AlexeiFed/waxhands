export function fixChatForeignKey(): Promise<void>;
//# sourceMappingURL=fix-chat-foreign-key.d.ts.map