export function cleanChatTables(): Promise<void>;
//# sourceMappingURL=clean-chat-tables.d.ts.map