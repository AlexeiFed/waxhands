export function getServices(req: any, res: any): Promise<void>;
export function getServiceById(req: any, res: any): Promise<void>;
export function createService(req: any, res: any): Promise<void>;
export function updateService(req: any, res: any): Promise<void>;
export function deleteService(req: any, res: any): Promise<void>;
export function addStyleToService(req: any, res: any): Promise<void>;
export function addOptionToService(req: any, res: any): Promise<void>;
export function updateServiceStyle(req: any, res: any): Promise<void>;
export function updateServiceOption(req: any, res: any): Promise<void>;
export function reorderServiceStyles(req: any, res: any): Promise<void>;
export function reorderServiceOptions(req: any, res: any): Promise<void>;
export function getServiceMedia(req: any, res: any): Promise<void>;
export function deleteServiceStyle(req: any, res: any): Promise<void>;
export function deleteServiceOption(req: any, res: any): Promise<void>;
//# sourceMappingURL=services.d.ts.map