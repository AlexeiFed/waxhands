export {};
//# sourceMappingURL=chat.d.ts.map