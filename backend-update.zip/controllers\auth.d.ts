export function login(req: any, res: any): Promise<void>;
export function register(req: any, res: any): Promise<void>;
export function getProfile(req: any, res: any): Promise<void>;
export function updateProfile(req: any, res: any): Promise<void>;
//# sourceMappingURL=auth.d.ts.map