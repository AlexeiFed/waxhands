export function removeCityField(): Promise<void>;
//# sourceMappingURL=remove-city-field.d.ts.map