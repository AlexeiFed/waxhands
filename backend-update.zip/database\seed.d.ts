export function seedData(): Promise<void>;
export function runSeed(): Promise<void>;
//# sourceMappingURL=seed.d.ts.map