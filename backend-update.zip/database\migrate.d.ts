export function createTables(): Promise<void>;
export function dropTables(): Promise<void>;
export function runMigrations(): Promise<void>;
//# sourceMappingURL=migrate.d.ts.map