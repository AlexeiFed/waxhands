export default migrateServicesTable;
declare function migrateServicesTable(): Promise<void>;
//# sourceMappingURL=migrate-services.d.ts.map