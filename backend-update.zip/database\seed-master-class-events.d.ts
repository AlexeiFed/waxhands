export function seedMasterClassEvents(): Promise<void>;
//# sourceMappingURL=seed-master-class-events.d.ts.map