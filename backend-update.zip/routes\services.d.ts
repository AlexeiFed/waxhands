export default router;
declare const router: import("@types/express-serve-static-core/index.js").Router;
//# sourceMappingURL=services.d.ts.map