export function checkServiceStructure(): Promise<void>;
//# sourceMappingURL=check-service-structure.d.ts.map