export function removeShiftField(): Promise<void>;
//# sourceMappingURL=remove-shift-field.d.ts.map