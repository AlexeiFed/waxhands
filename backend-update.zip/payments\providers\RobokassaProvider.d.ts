/**
 * @file: RobokassaProvider.ts
 * @description: Адаптер для RobokassaService, реализующий интерфейс IPaymentProvider
 * @dependencies: IPaymentProvider, RobokassaService
 * @created: 2025-10-16
 */
import { RobokassaService } from '../../services/robokassaService.js';
import { IPaymentProvider, PaymentInvoiceData, PaymentInvoiceResponse, PaymentNotification, PaymentRefundRequest, PaymentRefundResponse, PaymentRefundStatus } from '../interfaces/IPaymentProvider.js';
/**
 * Адаптер для RobokassaService
 * Преобразует общие типы IPaymentProvider в специфичные типы Robokassa
 */
export declare class RobokassaProvider implements IPaymentProvider {
    readonly providerName = "Robokassa";
    private robokassaService;
    constructor();
    /**
     * Преобразует PaymentInvoiceData в CreateRobokassaInvoiceData
     */
    private mapToRobokassaData;
    /**
     * Создает счет на оплату через Robokassa
     */
    createInvoice(data: PaymentInvoiceData): Promise<PaymentInvoiceResponse>;
    /**
     * Проверяет подпись уведомления от Robokassa (ResultURL)
     */
    verifyNotification(notification: PaymentNotification): boolean;
    /**
     * Проверяет подпись уведомления об успешной оплате (SuccessURL)
     */
    verifySuccessNotification(notification: PaymentNotification): boolean;
    /**
     * Создает возврат средств через Robokassa
     */
    createRefund(data: PaymentRefundRequest): Promise<PaymentRefundResponse>;
    /**
     * Получает статус возврата через Robokassa
     */
    getRefundStatus(requestId: string): Promise<PaymentRefundStatus | null>;
    /**
     * Проверяет возможность возврата для даты мастер-класса
     */
    isRefundAvailable(workshopDate: string): boolean;
    /**
     * Проверяет, доступна ли оплата для пользователя
     */
    isPaymentAvailable(userData: {
        surname?: string;
        phone?: string;
    }): boolean;
    /**
     * Получает OpKey для возврата через Robokassa XML API
     */
    getOpKeyForRefund(invoiceId: string): Promise<string | null>;
    /**
     * Получает сам экземпляр RobokassaService для специфичных операций
     * (используется для обратной совместимости)
     */
    getRobokassaService(): RobokassaService;
}
export declare const robokassaProvider: RobokassaProvider;
//# sourceMappingURL=RobokassaProvider.d.ts.map