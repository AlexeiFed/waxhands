export function checkSchema(): Promise<void>;
//# sourceMappingURL=check-schema.d.ts.map