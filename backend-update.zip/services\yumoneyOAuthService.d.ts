export class YuMoneyOAuthService {
    clientId: string;
    clientSecret: string;
    accessToken: null;
    tokenExpiry: number;
    /**
     * Получает access token для API ЮMoney
     */
    getAccessToken(): Promise<null>;
    /**
     * Получает информацию о платеже по operation_id
     */
    getPaymentInfo(operationId: any): Promise<{
        operation_id: any;
        status: string;
        amount: any;
        currency: any;
        label: any;
        sender: any;
        datetime: any;
    } | null>;
    /**
     * Создает платежную форму для счета
     */
    createPaymentForm(invoiceId: any, amount: any, description: any): Promise<string>;
    /**
     * Проверяет статус платежа по метке
     */
    checkPaymentByLabel(label: any): Promise<{
        operation_id: any;
        status: string;
        amount: any;
        currency: any;
        label: any;
        sender: any;
        datetime: any;
    } | null>;
    /**
     * Маппинг статуса платежа ЮMoney в наш формат
     */
    mapStatus(yumoneyStatus: any): "pending" | "success" | "failed";
    /**
     * Проверяет доступность API ЮMoney
     */
    checkApiHealth(): Promise<boolean>;
}
declare const _default: YuMoneyOAuthService;
export default _default;
//# sourceMappingURL=yumoneyOAuthService.d.ts.map