export function seedTestChild(): Promise<void>;
//# sourceMappingURL=seed-test-child.d.ts.map