export {};
//# sourceMappingURL=workshop-requests.d.ts.map