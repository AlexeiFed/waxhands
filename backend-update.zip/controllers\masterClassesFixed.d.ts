export function getMasterClassEventById(req: any, res: any): Promise<void>;
//# sourceMappingURL=masterClassesFixed.d.ts.map