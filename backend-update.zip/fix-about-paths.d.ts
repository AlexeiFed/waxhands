export {};
//# sourceMappingURL=fix-about-paths.d.ts.map