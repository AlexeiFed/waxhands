export {};
//# sourceMappingURL=about.d.ts.map