export function createAboutTable(): Promise<boolean>;
//# sourceMappingURL=create-about-table.d.ts.map