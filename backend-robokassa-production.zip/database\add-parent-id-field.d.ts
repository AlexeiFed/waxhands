/**
 * @file: add-parent-id-field.ts
 * @description: Миграция для добавления поля parent_id в таблицу users
 * @dependencies: database connection
 * @created: 2024-12-19
 */
export declare const addParentIdField: () => Promise<void>;
//# sourceMappingURL=add-parent-id-field.d.ts.map