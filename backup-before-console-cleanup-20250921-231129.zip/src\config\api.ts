export const API_BASE_URL = import.meta.env.VITE_API_URL || 'https://waxhands.ru/api';
export const WS_BASE_URL = import.meta.env.VITE_WS_URL || 'wss://waxhands.ru/ws';
